public class PictureRequest {
	private String svrIndexCode;
	private String picUri;
	private String netProtocol;

	public String getSvrIndexCode() {
		return svrIndexCode;
	}

	public void setSvrIndexCode(String svrIndexCode) {
		this.svrIndexCode = svrIndexCode;
	}

	public String getPicUri() {
		return picUri;
	}

	public void setPicUri(String picUri) {
		this.picUri = picUri;
	}

	public String getNetProtocol() {
		return netProtocol;
	}

	public void setNetProtocol(String netProtocol) {
		this.netProtocol = netProtocol;
	}
}
