public class GetRequest {
	private String channelIndexCode;

	public String getChannelIndexCode() {
		return channelIndexCode;
	}

	public void setChannelIndexCode(String channelIndexCode) {
		this.channelIndexCode = channelIndexCode;
	}
}
