public class SetRequest {
	private String channelIndexCode;
	private String status;

	public String getChannelIndexCode() {
		return channelIndexCode;
	}

	public void setChannelIndexCode(String channelIndexCode) {
		this.channelIndexCode = channelIndexCode;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
}
