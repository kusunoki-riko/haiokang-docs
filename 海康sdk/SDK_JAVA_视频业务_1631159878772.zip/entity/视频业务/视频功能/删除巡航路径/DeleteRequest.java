public class DeleteRequest {
	private String cameraIndexCode;
	private Integer cruiseIndex;

	public String getCameraIndexCode() {
		return cameraIndexCode;
	}

	public void setCameraIndexCode(String cameraIndexCode) {
		this.cameraIndexCode = cameraIndexCode;
	}

	public Integer getCruiseIndex() {
		return cruiseIndex;
	}

	public void setCruiseIndex(Integer cruiseIndex) {
		this.cruiseIndex = cruiseIndex;
	}
}
