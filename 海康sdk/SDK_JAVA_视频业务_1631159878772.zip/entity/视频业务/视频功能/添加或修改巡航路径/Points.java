public class Points {
	private Integer presetPointIndex;
	private Integer speed;
	private Integer standingTime;

	public Integer getPresetPointIndex() {
		return presetPointIndex;
	}

	public void setPresetPointIndex(Integer presetPointIndex) {
		this.presetPointIndex = presetPointIndex;
	}

	public Integer getSpeed() {
		return speed;
	}

	public void setSpeed(Integer speed) {
		this.speed = speed;
	}

	public Integer getStandingTime() {
		return standingTime;
	}

	public void setStandingTime(Integer standingTime) {
		this.standingTime = standingTime;
	}
}
