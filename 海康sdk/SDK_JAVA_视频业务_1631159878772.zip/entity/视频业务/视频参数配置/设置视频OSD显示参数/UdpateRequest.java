public class UdpateRequest {
	private String cameraIndexCode;
	private String channelName;
	private Integer isShowChanName;
	private Integer channelNameXPos;
	private Integer channelNameYPos;
	private Integer hourOSDType;
	private Integer isShowOSD;
	private Integer osdXPos;
	private Integer osdYPos;
	private Integer osdType;
	private Integer osdAttrib;
	private Integer isShowWeek;

	public String getCameraIndexCode() {
		return cameraIndexCode;
	}

	public void setCameraIndexCode(String cameraIndexCode) {
		this.cameraIndexCode = cameraIndexCode;
	}

	public String getChannelName() {
		return channelName;
	}

	public void setChannelName(String channelName) {
		this.channelName = channelName;
	}

	public Integer getIsShowChanName() {
		return isShowChanName;
	}

	public void setIsShowChanName(Integer isShowChanName) {
		this.isShowChanName = isShowChanName;
	}

	public Integer getChannelNameXPos() {
		return channelNameXPos;
	}

	public void setChannelNameXPos(Integer channelNameXPos) {
		this.channelNameXPos = channelNameXPos;
	}

	public Integer getChannelNameYPos() {
		return channelNameYPos;
	}

	public void setChannelNameYPos(Integer channelNameYPos) {
		this.channelNameYPos = channelNameYPos;
	}

	public Integer getHourOSDType() {
		return hourOSDType;
	}

	public void setHourOSDType(Integer hourOSDType) {
		this.hourOSDType = hourOSDType;
	}

	public Integer getIsShowOSD() {
		return isShowOSD;
	}

	public void setIsShowOSD(Integer isShowOSD) {
		this.isShowOSD = isShowOSD;
	}

	public Integer getOsdXPos() {
		return osdXPos;
	}

	public void setOsdXPos(Integer osdXPos) {
		this.osdXPos = osdXPos;
	}

	public Integer getOsdYPos() {
		return osdYPos;
	}

	public void setOsdYPos(Integer osdYPos) {
		this.osdYPos = osdYPos;
	}

	public Integer getOsdType() {
		return osdType;
	}

	public void setOsdType(Integer osdType) {
		this.osdType = osdType;
	}

	public Integer getOsdAttrib() {
		return osdAttrib;
	}

	public void setOsdAttrib(Integer osdAttrib) {
		this.osdAttrib = osdAttrib;
	}

	public Integer getIsShowWeek() {
		return isShowWeek;
	}

	public void setIsShowWeek(Integer isShowWeek) {
		this.isShowWeek = isShowWeek;
	}
}
