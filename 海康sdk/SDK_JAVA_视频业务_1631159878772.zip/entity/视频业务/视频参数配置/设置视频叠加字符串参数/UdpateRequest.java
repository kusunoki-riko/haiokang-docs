public class UdpateRequest {
	private String cameraIndexCode;
	private ArrayList<ShowStringParams> showStringParams;

	public String getCameraIndexCode() {
		return cameraIndexCode;
	}

	public void setCameraIndexCode(String cameraIndexCode) {
		this.cameraIndexCode = cameraIndexCode;
	}

	public ArrayList<ShowStringParams> getShowStringParams() {
		return showStringParams;
	}

	public void setShowStringParams(ArrayList<ShowStringParams> showStringParams) {
		this.showStringParams = showStringParams;
	}
}
