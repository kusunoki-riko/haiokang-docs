public class ShowStringParams {
	private String showString;
	private Integer isShow;
	private Integer xPos;
	private Integer yPos;

	public String getShowString() {
		return showString;
	}

	public void setShowString(String showString) {
		this.showString = showString;
	}

	public Integer getIsShow() {
		return isShow;
	}

	public void setIsShow(Integer isShow) {
		this.isShow = isShow;
	}

	public Integer getXPos() {
		return xPos;
	}

	public void setXPos(Integer xPos) {
		this.xPos = xPos;
	}

	public Integer getYPos() {
		return yPos;
	}

	public void setYPos(Integer yPos) {
		this.yPos = yPos;
	}
}
