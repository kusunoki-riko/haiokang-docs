public class ZoomInRequest {
	private Integer dlp_id;
	private Integer floatwnd_id;
	private String wnd_uri;
	private String type;

	public Integer getDlp_id() {
		return dlp_id;
	}

	public void setDlp_id(Integer dlp_id) {
		this.dlp_id = dlp_id;
	}

	public Integer getFloatwnd_id() {
		return floatwnd_id;
	}

	public void setFloatwnd_id(Integer floatwnd_id) {
		this.floatwnd_id = floatwnd_id;
	}

	public String getWnd_uri() {
		return wnd_uri;
	}

	public void setWnd_uri(String wnd_uri) {
		this.wnd_uri = wnd_uri;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
}
