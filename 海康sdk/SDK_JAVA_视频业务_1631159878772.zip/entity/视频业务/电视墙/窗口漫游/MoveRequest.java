public class MoveRequest {
	private Integer dlp_id;
	private Integer floatwnd_id;
	private Integer wnd_left;
	private Integer wnd_top;
	private Integer wnd_width;
	private Integer wnd_height;

	public Integer getDlp_id() {
		return dlp_id;
	}

	public void setDlp_id(Integer dlp_id) {
		this.dlp_id = dlp_id;
	}

	public Integer getFloatwnd_id() {
		return floatwnd_id;
	}

	public void setFloatwnd_id(Integer floatwnd_id) {
		this.floatwnd_id = floatwnd_id;
	}

	public Integer getWnd_left() {
		return wnd_left;
	}

	public void setWnd_left(Integer wnd_left) {
		this.wnd_left = wnd_left;
	}

	public Integer getWnd_top() {
		return wnd_top;
	}

	public void setWnd_top(Integer wnd_top) {
		this.wnd_top = wnd_top;
	}

	public Integer getWnd_width() {
		return wnd_width;
	}

	public void setWnd_width(Integer wnd_width) {
		this.wnd_width = wnd_width;
	}

	public Integer getWnd_height() {
		return wnd_height;
	}

	public void setWnd_height(Integer wnd_height) {
		this.wnd_height = wnd_height;
	}
}
