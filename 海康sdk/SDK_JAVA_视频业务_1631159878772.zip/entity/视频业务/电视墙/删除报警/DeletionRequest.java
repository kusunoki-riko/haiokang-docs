public class DeletionRequest {
	private String event_index;

	public String getEvent_index() {
		return event_index;
	}

	public void setEvent_index(String event_index) {
		this.event_index = event_index;
	}
}
