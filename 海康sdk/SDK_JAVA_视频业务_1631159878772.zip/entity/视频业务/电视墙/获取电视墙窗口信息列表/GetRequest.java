public class GetRequest {
	private Integer dlp_id;

	public Integer getDlp_id() {
		return dlp_id;
	}

	public void setDlp_id(Integer dlp_id) {
		this.dlp_id = dlp_id;
	}
}
