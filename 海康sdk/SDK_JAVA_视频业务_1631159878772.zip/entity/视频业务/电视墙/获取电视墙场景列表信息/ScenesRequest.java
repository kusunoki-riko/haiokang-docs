public class ScenesRequest {
}
