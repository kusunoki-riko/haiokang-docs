public class ZoomOutRequest {
	private Integer dlp_id;
	private Integer floatwnd_id;

	public Integer getDlp_id() {
		return dlp_id;
	}

	public void setDlp_id(Integer dlp_id) {
		this.dlp_id = dlp_id;
	}

	public Integer getFloatwnd_id() {
		return floatwnd_id;
	}

	public void setFloatwnd_id(Integer floatwnd_id) {
		this.floatwnd_id = floatwnd_id;
	}
}
