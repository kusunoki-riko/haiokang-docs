public class DivisionRequest {
	private Integer dlp_id;
	private Integer monitor_pos;
	private Integer div_num;

	public Integer getDlp_id() {
		return dlp_id;
	}

	public void setDlp_id(Integer dlp_id) {
		this.dlp_id = dlp_id;
	}

	public Integer getMonitor_pos() {
		return monitor_pos;
	}

	public void setMonitor_pos(Integer monitor_pos) {
		this.monitor_pos = monitor_pos;
	}

	public Integer getDiv_num() {
		return div_num;
	}

	public void setDiv_num(Integer div_num) {
		this.div_num = div_num;
	}
}
