public class Realplay_list {
	private String wnd_uri;

	public String getWnd_uri() {
		return wnd_uri;
	}

	public void setWnd_uri(String wnd_uri) {
		this.wnd_uri = wnd_uri;
	}
}
