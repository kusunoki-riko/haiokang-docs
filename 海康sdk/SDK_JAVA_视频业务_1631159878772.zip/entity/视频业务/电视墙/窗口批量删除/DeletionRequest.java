public class DeletionRequest {
	private ArrayList<Floatwnd_list> floatwnd_list;

	public ArrayList<Floatwnd_list> getFloatwnd_list() {
		return floatwnd_list;
	}

	public void setFloatwnd_list(ArrayList<Floatwnd_list> floatwnd_list) {
		this.floatwnd_list = floatwnd_list;
	}
}
