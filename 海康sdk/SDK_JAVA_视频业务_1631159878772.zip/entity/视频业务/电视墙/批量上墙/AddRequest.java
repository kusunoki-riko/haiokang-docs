public class AddRequest {
	private ArrayList<Realplay_list> realplay_list;

	public ArrayList<Realplay_list> getRealplay_list() {
		return realplay_list;
	}

	public void setRealplay_list(ArrayList<Realplay_list> realplay_list) {
		this.realplay_list = realplay_list;
	}
}
