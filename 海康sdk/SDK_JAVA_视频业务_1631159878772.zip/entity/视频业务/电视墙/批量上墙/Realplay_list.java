public class Realplay_list {
	private String wnd_uri;
	private String camera_indexcode;
	private Integer stream_type;

	public String getWnd_uri() {
		return wnd_uri;
	}

	public void setWnd_uri(String wnd_uri) {
		this.wnd_uri = wnd_uri;
	}

	public String getCamera_indexcode() {
		return camera_indexcode;
	}

	public void setCamera_indexcode(String camera_indexcode) {
		this.camera_indexcode = camera_indexcode;
	}

	public Integer getStream_type() {
		return stream_type;
	}

	public void setStream_type(Integer stream_type) {
		this.stream_type = stream_type;
	}
}
