public class LayerCtrlRequest {
	private Integer dlp_id;
	private Integer floatwnd_id;
	private Integer layer_ctrl;

	public Integer getDlp_id() {
		return dlp_id;
	}

	public void setDlp_id(Integer dlp_id) {
		this.dlp_id = dlp_id;
	}

	public Integer getFloatwnd_id() {
		return floatwnd_id;
	}

	public void setFloatwnd_id(Integer floatwnd_id) {
		this.floatwnd_id = floatwnd_id;
	}

	public Integer getLayer_ctrl() {
		return layer_ctrl;
	}

	public void setLayer_ctrl(Integer layer_ctrl) {
		this.layer_ctrl = layer_ctrl;
	}
}
