public class AdditionRequest {
	private Integer dlp_id;
	private String name;
	private Integer device_scene;

	public Integer getDlp_id() {
		return dlp_id;
	}

	public void setDlp_id(Integer dlp_id) {
		this.dlp_id = dlp_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getDevice_scene() {
		return device_scene;
	}

	public void setDevice_scene(Integer device_scene) {
		this.device_scene = device_scene;
	}
}
