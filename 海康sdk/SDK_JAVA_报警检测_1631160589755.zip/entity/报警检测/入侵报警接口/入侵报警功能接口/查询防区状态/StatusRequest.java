public class StatusRequest {
	private ArrayList<String> defenceIndexCodes;

	public ArrayList<String> getDefenceIndexCodes() {
		return defenceIndexCodes;
	}

	public void setDefenceIndexCodes(ArrayList<String> defenceIndexCodes) {
		this.defenceIndexCodes = defenceIndexCodes;
	}
}
