public class UpdateRequest {
	private String channelType;
	private String channelIndexCode;
	private String channelName;

	public String getChannelType() {
		return channelType;
	}

	public void setChannelType(String channelType) {
		this.channelType = channelType;
	}

	public String getChannelIndexCode() {
		return channelIndexCode;
	}

	public void setChannelIndexCode(String channelIndexCode) {
		this.channelIndexCode = channelIndexCode;
	}

	public String getChannelName() {
		return channelName;
	}

	public void setChannelName(String channelName) {
		this.channelName = channelName;
	}
}
