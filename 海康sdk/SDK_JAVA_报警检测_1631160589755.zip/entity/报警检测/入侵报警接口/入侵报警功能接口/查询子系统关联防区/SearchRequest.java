public class SearchRequest {
	private ArrayList<String> subSysIndexCodes;

	public ArrayList<String> getSubSysIndexCodes() {
		return subSysIndexCodes;
	}

	public void setSubSysIndexCodes(ArrayList<String> subSysIndexCodes) {
		this.subSysIndexCodes = subSysIndexCodes;
	}
}
