public class BindingsRequest {
	private String regionIndexCode;
	private ArrayList<String> defenceIndexCodes;

	public String getRegionIndexCode() {
		return regionIndexCode;
	}

	public void setRegionIndexCode(String regionIndexCode) {
		this.regionIndexCode = regionIndexCode;
	}

	public ArrayList<String> getDefenceIndexCodes() {
		return defenceIndexCodes;
	}

	public void setDefenceIndexCodes(ArrayList<String> defenceIndexCodes) {
		this.defenceIndexCodes = defenceIndexCodes;
	}
}
