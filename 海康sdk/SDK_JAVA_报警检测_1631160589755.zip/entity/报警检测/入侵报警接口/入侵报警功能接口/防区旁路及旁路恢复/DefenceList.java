public class DefenceList {
	private String defenceIndexCode;
	private Integer status;

	public String getDefenceIndexCode() {
		return defenceIndexCode;
	}

	public void setDefenceIndexCode(String defenceIndexCode) {
		this.defenceIndexCode = defenceIndexCode;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}
}
