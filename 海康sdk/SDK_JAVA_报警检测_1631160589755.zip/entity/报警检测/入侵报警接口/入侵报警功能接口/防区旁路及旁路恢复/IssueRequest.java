public class IssueRequest {
	private ArrayList<DefenceList> defenceList;

	public ArrayList<DefenceList> getDefenceList() {
		return defenceList;
	}

	public void setDefenceList(ArrayList<DefenceList> defenceList) {
		this.defenceList = defenceList;
	}
}
