public class AddRequest {
	private String subSystemIndexCode;
	private ArrayList<String> defenceIndexCodes;

	public String getSubSystemIndexCode() {
		return subSystemIndexCode;
	}

	public void setSubSystemIndexCode(String subSystemIndexCode) {
		this.subSystemIndexCode = subSystemIndexCode;
	}

	public ArrayList<String> getDefenceIndexCodes() {
		return defenceIndexCodes;
	}

	public void setDefenceIndexCodes(ArrayList<String> defenceIndexCodes) {
		this.defenceIndexCodes = defenceIndexCodes;
	}
}
