public class DefenceRequest {
	private String deviceIndexCode;

	public String getDeviceIndexCode() {
		return deviceIndexCode;
	}

	public void setDeviceIndexCode(String deviceIndexCode) {
		this.deviceIndexCode = deviceIndexCode;
	}
}
