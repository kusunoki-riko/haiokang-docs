public class IssueRequest {
	private ArrayList<SubSystemList> subSystemList;

	public ArrayList<SubSystemList> getSubSystemList() {
		return subSystemList;
	}

	public void setSubSystemList(ArrayList<SubSystemList> subSystemList) {
		this.subSystemList = subSystemList;
	}
}
