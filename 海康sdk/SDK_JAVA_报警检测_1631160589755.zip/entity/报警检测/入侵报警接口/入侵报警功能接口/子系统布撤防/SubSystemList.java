public class SubSystemList {
	private String subSystemIndexCode;
	private Integer status;

	public String getSubSystemIndexCode() {
		return subSystemIndexCode;
	}

	public void setSubSystemIndexCode(String subSystemIndexCode) {
		this.subSystemIndexCode = subSystemIndexCode;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}
}
