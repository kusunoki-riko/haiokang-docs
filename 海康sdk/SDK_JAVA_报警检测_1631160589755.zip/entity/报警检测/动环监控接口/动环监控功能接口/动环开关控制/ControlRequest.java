public class ControlRequest {
	private String indexCodes;
	private Integer type;

	public String getIndexCodes() {
		return indexCodes;
	}

	public void setIndexCodes(String indexCodes) {
		this.indexCodes = indexCodes;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}
}
