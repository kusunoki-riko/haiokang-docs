public class SearchRequest {
	private Integer pageNo;
	private Integer pageSize;
	private String regionIndexCode;
	private Boolean isIncludeSonRegion;
	private String name;

	public Integer getPageNo() {
		return pageNo;
	}

	public void setPageNo(Integer pageNo) {
		this.pageNo = pageNo;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}

	public String getRegionIndexCode() {
		return regionIndexCode;
	}

	public void setRegionIndexCode(String regionIndexCode) {
		this.regionIndexCode = regionIndexCode;
	}

	public Boolean getIsIncludeSonRegion() {
		return isIncludeSonRegion;
	}

	public void setIsIncludeSonRegion(Boolean isIncludeSonRegion) {
		this.isIncludeSonRegion = isIncludeSonRegion;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
