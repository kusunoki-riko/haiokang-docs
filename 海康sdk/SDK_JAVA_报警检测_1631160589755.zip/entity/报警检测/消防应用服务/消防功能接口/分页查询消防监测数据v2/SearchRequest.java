public class SearchRequest {
	private String regionIndexCode;
	private Integer includeDown;
	private ArrayList<String> resourceTypeCodes;
	private Integer pageSize;
	private Integer pageNo;

	public String getRegionIndexCode() {
		return regionIndexCode;
	}

	public void setRegionIndexCode(String regionIndexCode) {
		this.regionIndexCode = regionIndexCode;
	}

	public Integer getIncludeDown() {
		return includeDown;
	}

	public void setIncludeDown(Integer includeDown) {
		this.includeDown = includeDown;
	}

	public ArrayList<String> getResourceTypeCodes() {
		return resourceTypeCodes;
	}

	public void setResourceTypeCodes(ArrayList<String> resourceTypeCodes) {
		this.resourceTypeCodes = resourceTypeCodes;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}

	public Integer getPageNo() {
		return pageNo;
	}

	public void setPageNo(Integer pageNo) {
		this.pageNo = pageNo;
	}
}
