public class SearchRequest {
	private Integer includeSubNode;
	private String regionIndexCode;
	private String deviceName;
	private Integer deviceType;
	private Integer online;
	private Integer unitStatus;
	private String deviceIndexCode;
	private Integer pageNo;
	private Integer pageSize;

	public Integer getIncludeSubNode() {
		return includeSubNode;
	}

	public void setIncludeSubNode(Integer includeSubNode) {
		this.includeSubNode = includeSubNode;
	}

	public String getRegionIndexCode() {
		return regionIndexCode;
	}

	public void setRegionIndexCode(String regionIndexCode) {
		this.regionIndexCode = regionIndexCode;
	}

	public String getDeviceName() {
		return deviceName;
	}

	public void setDeviceName(String deviceName) {
		this.deviceName = deviceName;
	}

	public Integer getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(Integer deviceType) {
		this.deviceType = deviceType;
	}

	public Integer getOnline() {
		return online;
	}

	public void setOnline(Integer online) {
		this.online = online;
	}

	public Integer getUnitStatus() {
		return unitStatus;
	}

	public void setUnitStatus(Integer unitStatus) {
		this.unitStatus = unitStatus;
	}

	public String getDeviceIndexCode() {
		return deviceIndexCode;
	}

	public void setDeviceIndexCode(String deviceIndexCode) {
		this.deviceIndexCode = deviceIndexCode;
	}

	public Integer getPageNo() {
		return pageNo;
	}

	public void setPageNo(Integer pageNo) {
		this.pageNo = pageNo;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}
}
