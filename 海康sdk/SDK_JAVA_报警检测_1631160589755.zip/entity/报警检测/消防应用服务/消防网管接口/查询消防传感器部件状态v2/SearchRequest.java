public class SearchRequest {
	private Integer includeSubNode;
	private String regionIndexCode;
	private String cn;
	private Integer channelType;
	private Integer unitStatus;
	private String channelIndexCode;
	private Integer pageNo;
	private Integer pageSize;

	public Integer getIncludeSubNode() {
		return includeSubNode;
	}

	public void setIncludeSubNode(Integer includeSubNode) {
		this.includeSubNode = includeSubNode;
	}

	public String getRegionIndexCode() {
		return regionIndexCode;
	}

	public void setRegionIndexCode(String regionIndexCode) {
		this.regionIndexCode = regionIndexCode;
	}

	public String getCn() {
		return cn;
	}

	public void setCn(String cn) {
		this.cn = cn;
	}

	public Integer getChannelType() {
		return channelType;
	}

	public void setChannelType(Integer channelType) {
		this.channelType = channelType;
	}

	public Integer getUnitStatus() {
		return unitStatus;
	}

	public void setUnitStatus(Integer unitStatus) {
		this.unitStatus = unitStatus;
	}

	public String getChannelIndexCode() {
		return channelIndexCode;
	}

	public void setChannelIndexCode(String channelIndexCode) {
		this.channelIndexCode = channelIndexCode;
	}

	public Integer getPageNo() {
		return pageNo;
	}

	public void setPageNo(Integer pageNo) {
		this.pageNo = pageNo;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}
}
