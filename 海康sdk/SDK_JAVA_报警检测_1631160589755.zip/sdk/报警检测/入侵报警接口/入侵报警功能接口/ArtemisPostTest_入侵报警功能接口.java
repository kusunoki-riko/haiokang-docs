
import java.util.HashMap;
import java.util.Map;

import com.alibaba.fastjson.JSONObject;
import com.hikvision.artemis.sdk.ArtemisHttpUtil;
import com.hikvision.artemis.sdk.config.ArtemisConfig;


/**
 * Auto Create on 2021-09-09 12:09:49
 */
public class ArtemisPostTest_入侵报警功能接口 {
	/**
	 * STEP1：设置平台参数，根据实际情况,设置host appkey appsecret 三个参数.
	 */
	static {
		ArtemisConfig.host = "ip:port";// 平台门户/nginx的IP和端口（必须使用https协议，https端口默认为443）
		ArtemisConfig.appKey = "请填入appKey"; // 秘钥appkey
		ArtemisConfig.appSecret = "请填入appSecret";// 秘钥appSecret
	}
	/**
	 * STEP2：设置OpenAPI接口的上下文
	 */
	private static final String ARTEMIS_PATH = "/artemis";

	//报警主机通道名称修改
	public static String update(UpdateRequest updateRequest ){
		String updateDataApi = ARTEMIS_PATH +"/api/scpms/v1/channels/update";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",updateDataApi);
			}
		};
		String body=JSON.toJSONString(updateRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//子系统布撤防
	public static String issue(IssueRequest issueRequest ){
		String issueDataApi = ARTEMIS_PATH +"/api/scpms/v1/subsystem/status/issue";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",issueDataApi);
			}
		};
		String body=JSON.toJSONString(issueRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//子系统消警
	public static String eliminate(EliminateRequest eliminateRequest ){
		String eliminateDataApi = ARTEMIS_PATH +"/api/scpms/v1/subsystem/alarm/eliminate";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",eliminateDataApi);
			}
		};
		String body=JSON.toJSONString(eliminateRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//查询子系统状态
	public static String status(StatusRequest statusRequest ){
		String statusDataApi = ARTEMIS_PATH +"/api/scpms/v1/subSys/status";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",statusDataApi);
			}
		};
		String body=JSON.toJSONString(statusRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//添加子系统关联防区
	public static String add(AddRequest addRequest ){
		String addDataApi = ARTEMIS_PATH +"/api/scpms/v1/subsystem/defences/add";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",addDataApi);
			}
		};
		String body=JSON.toJSONString(addRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//查询子系统关联防区
	public static String search(SearchRequest searchRequest ){
		String searchDataApi = ARTEMIS_PATH +"/api/scpms/v1/subsystem/defences/search";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",searchDataApi);
			}
		};
		String body=JSON.toJSONString(searchRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//删除子系统关联防区
	public static String delete(DeleteRequest deleteRequest ){
		String deleteDataApi = ARTEMIS_PATH +"/api/scpms/v1/subsystem/defences/delete";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",deleteDataApi);
			}
		};
		String body=JSON.toJSONString(deleteRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//查询防区状态
	public static String status(StatusRequest statusRequest ){
		String statusDataApi = ARTEMIS_PATH +"/api/scpms/v1/defence/status";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",statusDataApi);
			}
		};
		String body=JSON.toJSONString(statusRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//防区旁路及旁路恢复
	public static String issue(IssueRequest issueRequest ){
		String issueDataApi = ARTEMIS_PATH +"/api/scpms/v1/defence/status/issue";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",issueDataApi);
			}
		};
		String body=JSON.toJSONString(issueRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//入侵报警事件日志查询v2
	public static String searches(SearchesRequest searchesRequest ){
		String searchesDataApi = ARTEMIS_PATH +"/api/scpms/v2/eventLogs/searches";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",searchesDataApi);
			}
		};
		String body=JSON.toJSONString(searchesRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//查询设备下所有防区
	public static String defence(DefenceRequest defenceRequest ){
		String defenceDataApi = ARTEMIS_PATH +"/api/scpms/v1/iasDevice/defence";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",defenceDataApi);
			}
		};
		String body=JSON.toJSONString(defenceRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//防区添加到区域
	public static String bindings(BindingsRequest bindingsRequest ){
		String bindingsDataApi = ARTEMIS_PATH +"/api/scpms/v1/defence/region/bindings";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",bindingsDataApi);
			}
		};
		String body=JSON.toJSONString(bindingsRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}


}
