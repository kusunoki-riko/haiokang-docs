
import java.util.HashMap;
import java.util.Map;

import com.alibaba.fastjson.JSONObject;
import com.hikvision.artemis.sdk.ArtemisHttpUtil;
import com.hikvision.artemis.sdk.config.ArtemisConfig;


/**
 * Auto Create on 2021-09-09 12:09:49
 */
public class ArtemisPostTest_动环监控功能接口 {
	/**
	 * STEP1：设置平台参数，根据实际情况,设置host appkey appsecret 三个参数.
	 */
	static {
		ArtemisConfig.host = "ip:port";// 平台门户/nginx的IP和端口（必须使用https协议，https端口默认为443）
		ArtemisConfig.appKey = "请填入appKey"; // 秘钥appkey
		ArtemisConfig.appSecret = "请填入appSecret";// 秘钥appSecret
	}
	/**
	 * STEP2：设置OpenAPI接口的上下文
	 */
	private static final String ARTEMIS_PATH = "/artemis";

	//分页查询动环传感器
	public static String search(SearchRequest searchRequest ){
		String searchDataApi = ARTEMIS_PATH +"/api/pems/v1/monitor/search";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",searchDataApi);
			}
		};
		String body=JSON.toJSONString(searchRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//动环传感器布防
	public static String layout(LayoutRequest layoutRequest ){
		String layoutDataApi = ARTEMIS_PATH +"/api/pems/v1/monitor/transducer/layout";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",layoutDataApi);
			}
		};
		String body=JSON.toJSONString(layoutRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//动环传感器撤防
	public static String disarming(DisarmingRequest disarmingRequest ){
		String disarmingDataApi = ARTEMIS_PATH +"/api/pems/v1/monitor/transducer/disarming";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",disarmingDataApi);
			}
		};
		String body=JSON.toJSONString(disarmingRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//分页查询动环报警输入
	public static String search(SearchRequest searchRequest ){
		String searchDataApi = ARTEMIS_PATH +"/api/pems/v1/alarm_in/search";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",searchDataApi);
			}
		};
		String body=JSON.toJSONString(searchRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//动环报警输入布防
	public static String layout(LayoutRequest layoutRequest ){
		String layoutDataApi = ARTEMIS_PATH +"/api/pems/v1/monitor/ioIn/layout";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",layoutDataApi);
			}
		};
		String body=JSON.toJSONString(layoutRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//动环报警输入撤防
	public static String disarming(DisarmingRequest disarmingRequest ){
		String disarmingDataApi = ARTEMIS_PATH +"/api/pems/v1/monitor/ioIn/disarming";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",disarmingDataApi);
			}
		};
		String body=JSON.toJSONString(disarmingRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//分页查询动环环境量
	public static String search(SearchRequest searchRequest ){
		String searchDataApi = ARTEMIS_PATH +"/api/pems/v1/sensor/search";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",searchDataApi);
			}
		};
		String body=JSON.toJSONString(searchRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//动环环境量布防
	public static String layout(LayoutRequest layoutRequest ){
		String layoutDataApi = ARTEMIS_PATH +"/api/pems/v1/monitor/sensor/layout";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",layoutDataApi);
			}
		};
		String body=JSON.toJSONString(layoutRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//动环环境量撤防
	public static String disarming(DisarmingRequest disarmingRequest ){
		String disarmingDataApi = ARTEMIS_PATH +"/api/pems/v1/monitor/sensor/disarming";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",disarmingDataApi);
			}
		};
		String body=JSON.toJSONString(disarmingRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//动环开关控制
	public static String control(ControlRequest controlRequest ){
		String controlDataApi = ARTEMIS_PATH +"/api/pems/v1/monitor/pemsIoOut/control";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",controlDataApi);
			}
		};
		String body=JSON.toJSONString(controlRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//增量获取动环开关数据
	public static String timeRange(TimeRangeRequest timeRangeRequest ){
		String timeRangeDataApi = ARTEMIS_PATH +"/api/resource/v1/pemsIoOut/timeRange";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",timeRangeDataApi);
			}
		};
		String body=JSON.toJSONString(timeRangeRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//增量获取动环设备数据
	public static String timeRange(TimeRangeRequest timeRangeRequest ){
		String timeRangeDataApi = ARTEMIS_PATH +"/api/resource/v1/peDevice/timeRange";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",timeRangeDataApi);
			}
		};
		String body=JSON.toJSONString(timeRangeRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//查询动环开关列表
	public static String search(SearchRequest searchRequest ){
		String searchDataApi = ARTEMIS_PATH +"/api/resource/v1/pemsIoOut/search";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",searchDataApi);
			}
		};
		String body=JSON.toJSONString(searchRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//查询动环设备列表
	public static String search(SearchRequest searchRequest ){
		String searchDataApi = ARTEMIS_PATH +"/api/resource/v1/peDevice/search";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",searchDataApi);
			}
		};
		String body=JSON.toJSONString(searchRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//获取传感器布防状态
	public static String state(StateRequest stateRequest ){
		String stateDataApi = ARTEMIS_PATH +"/api/pems/v1/defense/transducer/state";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",stateDataApi);
			}
		};
		String body=JSON.toJSONString(stateRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//获取报警输入布防状态
	public static String state(StateRequest stateRequest ){
		String stateDataApi = ARTEMIS_PATH +"/api/pems/v1/defense/ioIn/state";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",stateDataApi);
			}
		};
		String body=JSON.toJSONString(stateRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//获取环境量布防状态
	public static String state(StateRequest stateRequest ){
		String stateDataApi = ARTEMIS_PATH +"/api/pems/v1/defense/sensor/state";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",stateDataApi);
			}
		};
		String body=JSON.toJSONString(stateRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}


}
