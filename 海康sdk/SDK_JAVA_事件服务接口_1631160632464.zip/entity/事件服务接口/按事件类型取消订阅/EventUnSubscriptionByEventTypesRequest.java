public class EventUnSubscriptionByEventTypesRequest {
	private ArrayList<Integer> eventTypes;

	public ArrayList<Integer> getEventTypes() {
		return eventTypes;
	}

	public void setEventTypes(ArrayList<Integer> eventTypes) {
		this.eventTypes = eventTypes;
	}
}
