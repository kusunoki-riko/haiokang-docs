public class SearchRequest {
	private Integer pageSize;
	private Integer pageNo;
	private String startTime;
	private String endTime;
	private ArrayList<String> alarmIds;
	private ArrayList<String> resourceCodes;
	private ArrayList<String> groupIds;
	private String personName;

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}

	public Integer getPageNo() {
		return pageNo;
	}

	public void setPageNo(Integer pageNo) {
		this.pageNo = pageNo;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public ArrayList<String> getAlarmIds() {
		return alarmIds;
	}

	public void setAlarmIds(ArrayList<String> alarmIds) {
		this.alarmIds = alarmIds;
	}

	public ArrayList<String> getResourceCodes() {
		return resourceCodes;
	}

	public void setResourceCodes(ArrayList<String> resourceCodes) {
		this.resourceCodes = resourceCodes;
	}

	public ArrayList<String> getGroupIds() {
		return groupIds;
	}

	public void setGroupIds(ArrayList<String> groupIds) {
		this.groupIds = groupIds;
	}

	public String getPersonName() {
		return personName;
	}

	public void setPersonName(String personName) {
		this.personName = personName;
	}
}
