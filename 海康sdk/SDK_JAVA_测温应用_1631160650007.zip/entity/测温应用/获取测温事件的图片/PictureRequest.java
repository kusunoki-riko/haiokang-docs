public class PictureRequest {
	private String svrIndexCode;
	private String picUri;

	public String getSvrIndexCode() {
		return svrIndexCode;
	}

	public void setSvrIndexCode(String svrIndexCode) {
		this.svrIndexCode = svrIndexCode;
	}

	public String getPicUri() {
		return picUri;
	}

	public void setPicUri(String picUri) {
		this.picUri = picUri;
	}
}
