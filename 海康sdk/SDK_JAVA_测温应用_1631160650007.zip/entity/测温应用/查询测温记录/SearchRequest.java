public class SearchRequest {
	private Integer pageSize;
	private Integer pageNo;
	private String startTime;
	private String endTime;
	private String alarmId;
	private String resourceName;
	private ArrayList<String> groupIds;
	private ArrayList<String> resourceCodes;
	private Integer alarmType;
	private String sort;
	private String order;

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}

	public Integer getPageNo() {
		return pageNo;
	}

	public void setPageNo(Integer pageNo) {
		this.pageNo = pageNo;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public String getAlarmId() {
		return alarmId;
	}

	public void setAlarmId(String alarmId) {
		this.alarmId = alarmId;
	}

	public String getResourceName() {
		return resourceName;
	}

	public void setResourceName(String resourceName) {
		this.resourceName = resourceName;
	}

	public ArrayList<String> getGroupIds() {
		return groupIds;
	}

	public void setGroupIds(ArrayList<String> groupIds) {
		this.groupIds = groupIds;
	}

	public ArrayList<String> getResourceCodes() {
		return resourceCodes;
	}

	public void setResourceCodes(ArrayList<String> resourceCodes) {
		this.resourceCodes = resourceCodes;
	}

	public Integer getAlarmType() {
		return alarmType;
	}

	public void setAlarmType(Integer alarmType) {
		this.alarmType = alarmType;
	}

	public String getSort() {
		return sort;
	}

	public void setSort(String sort) {
		this.sort = sort;
	}

	public String getOrder() {
		return order;
	}

	public void setOrder(String order) {
		this.order = order;
	}
}
