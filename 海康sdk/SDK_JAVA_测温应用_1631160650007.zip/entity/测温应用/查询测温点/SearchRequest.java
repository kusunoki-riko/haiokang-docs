public class SearchRequest {
	private Integer pageNo;
	private Integer pageSize;
	private String resourceName;
	private ArrayList<String> groupIds;
	private ArrayList<String> resourceCodes;
	private Integer resourceType;

	public Integer getPageNo() {
		return pageNo;
	}

	public void setPageNo(Integer pageNo) {
		this.pageNo = pageNo;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}

	public String getResourceName() {
		return resourceName;
	}

	public void setResourceName(String resourceName) {
		this.resourceName = resourceName;
	}

	public ArrayList<String> getGroupIds() {
		return groupIds;
	}

	public void setGroupIds(ArrayList<String> groupIds) {
		this.groupIds = groupIds;
	}

	public ArrayList<String> getResourceCodes() {
		return resourceCodes;
	}

	public void setResourceCodes(ArrayList<String> resourceCodes) {
		this.resourceCodes = resourceCodes;
	}

	public Integer getResourceType() {
		return resourceType;
	}

	public void setResourceType(Integer resourceType) {
		this.resourceType = resourceType;
	}
}
