
import java.util.HashMap;
import java.util.Map;

import com.alibaba.fastjson.JSONObject;
import com.hikvision.artemis.sdk.ArtemisHttpUtil;
import com.hikvision.artemis.sdk.config.ArtemisConfig;


/**
 * Auto Create on 2021-09-09 12:09:36
 */
public class ArtemisPostTest_停车场功能接口 {
	/**
	 * STEP1：设置平台参数，根据实际情况,设置host appkey appsecret 三个参数.
	 */
	static {
		ArtemisConfig.host = "ip:port";// 平台门户/nginx的IP和端口（必须使用https协议，https端口默认为443）
		ArtemisConfig.appKey = "请填入appKey"; // 秘钥appkey
		ArtemisConfig.appSecret = "请填入appSecret";// 秘钥appSecret
	}
	/**
	 * STEP2：设置OpenAPI接口的上下文
	 */
	private static final String ARTEMIS_PATH = "/artemis";

	//查询停车账单(根据停车库和车牌号)
	public static String quickPreBill(QuickPreBillRequest quickPreBillRequest ){
		String quickPreBillDataApi = ARTEMIS_PATH +"/api/pms/v1/pay/quickPreBill";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",quickPreBillDataApi);
			}
		};
		String body=JSON.toJSONString(quickPreBillRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//查询场内车停车信息
	public static String page(PageRequest pageRequest ){
		String pageDataApi = ARTEMIS_PATH +"/api/pms/v1/tempCarInRecords/page";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",pageDataApi);
			}
		};
		String body=JSON.toJSONString(pageRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//查询停车账单(根据停车信息)
	public static String preBill(PreBillRequest preBillRequest ){
		String preBillDataApi = ARTEMIS_PATH +"/api/pms/v1/pay/preBill";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",preBillDataApi);
			}
		};
		String body=JSON.toJSONString(preBillRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//账单支付确认v2
	public static String receipt(ReceiptRequest receiptRequest ){
		String receiptDataApi = ARTEMIS_PATH +"/api/pms/v2/pay/receipt";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",receiptDataApi);
			}
		};
		String body=JSON.toJSONString(receiptRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//查询车辆缴费记录
	public static String search(SearchRequest searchRequest ){
		String searchDataApi = ARTEMIS_PATH +"/api/pms/v1/charge_bill/record/search";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",searchDataApi);
			}
		};
		String body=JSON.toJSONString(searchRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//查询停车库临时车收费规则
	public static String chargeRules(ChargeRulesRequest chargeRulesRequest ){
		String chargeRulesDataApi = ARTEMIS_PATH +"/api/pms/v1/chargeRules";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",chargeRulesDataApi);
			}
		};
		String body=JSON.toJSONString(chargeRulesRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//查询特定临时车收费规则
	public static String chargeRule(ChargeRuleRequest chargeRuleRequest ){
		String chargeRuleDataApi = ARTEMIS_PATH +"/api/pms/v1/chargeRule";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",chargeRuleDataApi);
			}
		};
		String body=JSON.toJSONString(chargeRuleRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//根据停车场编码反控道闸
	public static String deviceControlBatch(DeviceControlBatchRequest deviceControlBatchRequest ){
		String deviceControlBatchDataApi = ARTEMIS_PATH +"/api/pms/v1/deviceControlBatch";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",deviceControlBatchDataApi);
			}
		};
		String body=JSON.toJSONString(deviceControlBatchRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//根据车道编码反控道闸
	public static String deviceControl(DeviceControlRequest deviceControlRequest ){
		String deviceControlDataApi = ARTEMIS_PATH +"/api/pms/v1/deviceControl";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",deviceControlDataApi);
			}
		};
		String body=JSON.toJSONString(deviceControlRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//查询停车库剩余车位数
	public static String remainSpaceNum(RemainSpaceNumRequest remainSpaceNumRequest ){
		String remainSpaceNumDataApi = ARTEMIS_PATH +"/api/pms/v1/park/remainSpaceNum";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",remainSpaceNumDataApi);
			}
		};
		String body=JSON.toJSONString(remainSpaceNumRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//车位预约v2
	public static String addition(AdditionRequest additionRequest ){
		String additionDataApi = ARTEMIS_PATH +"/api/pms/v2/parkingSpace/reservations/addition";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",additionDataApi);
			}
		};
		String body=JSON.toJSONString(additionRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//查询预约记录v2
	public static String page(PageRequest pageRequest ){
		String pageDataApi = ARTEMIS_PATH +"/api/pms/v2/reserveRecord/page";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",pageDataApi);
			}
		};
		String body=JSON.toJSONString(pageRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//取消车位预约
	public static String deletion(DeletionRequest deletionRequest ){
		String deletionDataApi = ARTEMIS_PATH +"/api/pms/v1/parkingSpace/reservations/deletion";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",deletionDataApi);
			}
		};
		String body=JSON.toJSONString(deletionRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//车辆充值
	public static String charge(ChargeRequest chargeRequest ){
		String chargeDataApi = ARTEMIS_PATH +"/api/pms/v1/car/charge";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",chargeDataApi);
			}
		};
		String body=JSON.toJSONString(chargeRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//取消车辆包期
	public static String deletion(DeletionRequest deletionRequest ){
		String deletionDataApi = ARTEMIS_PATH +"/api/pms/v1/car/charge/deletion";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",deletionDataApi);
			}
		};
		String body=JSON.toJSONString(deletionRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//查询车辆包期信息
	public static String page(PageRequest pageRequest ){
		String pageDataApi = ARTEMIS_PATH +"/api/pms/v1/car/charge/page";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",pageDataApi);
			}
		};
		String body=JSON.toJSONString(pageRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//取消车位绑定车辆
	public static String delete(DeleteRequest deleteRequest ){
		String deleteDataApi = ARTEMIS_PATH +"/api/pms/v1/parking_space/car_bind/delete";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",deleteDataApi);
			}
		};
		String body=JSON.toJSONString(deleteRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//车辆布控
	public static String addition(AdditionRequest additionRequest ){
		String additionDataApi = ARTEMIS_PATH +"/api/pms/v1/alarmCar/addition";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",additionDataApi);
			}
		};
		String body=JSON.toJSONString(additionRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//查询车辆充值退款记录
	public static String search(SearchRequest searchRequest ){
		String searchDataApi = ARTEMIS_PATH +"/api/pms/v1/car_charge/record/search";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",searchDataApi);
			}
		};
		String body=JSON.toJSONString(searchRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//查询布控车辆
	public static String page(PageRequest pageRequest ){
		String pageDataApi = ARTEMIS_PATH +"/api/pms/v1/alarmCar/page";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",pageDataApi);
			}
		};
		String body=JSON.toJSONString(pageRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//取消车辆布控
	public static String deletion(DeletionRequest deletionRequest ){
		String deletionDataApi = ARTEMIS_PATH +"/api/pms/v1/alarmCar/deletion";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",deletionDataApi);
			}
		};
		String body=JSON.toJSONString(deletionRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//查询过车记录
	public static String page(PageRequest pageRequest ){
		String pageDataApi = ARTEMIS_PATH +"/api/pms/v1/crossRecords/page";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",pageDataApi);
			}
		};
		String body=JSON.toJSONString(pageRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//查询车辆抓拍图片
	public static String image(ImageRequest imageRequest ){
		String imageDataApi = ARTEMIS_PATH +"/api/pms/v1/image";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",imageDataApi);
			}
		};
		String body=JSON.toJSONString(imageRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//查询账户充值退款记录
	public static String search(SearchRequest searchRequest ){
		String searchDataApi = ARTEMIS_PATH +"/api/pms/v1/account_charge/record/search";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",searchDataApi);
			}
		};
		String body=JSON.toJSONString(searchRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//查询车位信息
	public static String spaceNo(SpaceNoRequest spaceNoRequest ){
		String spaceNoDataApi = ARTEMIS_PATH +"/api/pms/v1/parkingSpace/spaceNo";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",spaceNoDataApi);
			}
		};
		String body=JSON.toJSONString(spaceNoRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//车位绑定车辆
	public static String add(AddRequest addRequest ){
		String addDataApi = ARTEMIS_PATH +"/api/pms/v1/parking_space/car_bind/add";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",addDataApi);
			}
		};
		String body=JSON.toJSONString(addRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//查询车辆在车位上的停车信息
	public static String query(QueryRequest queryRequest ){
		String queryDataApi = ARTEMIS_PATH +"/api/pms/v1/parkingRecord/query";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",queryDataApi);
			}
		};
		String body=JSON.toJSONString(queryRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//获取寻车路线
	public static String vehicleRoute(VehicleRouteRequest vehicleRouteRequest ){
		String vehicleRouteDataApi = ARTEMIS_PATH +"/api/pms/v1/map/vehicleRoute";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",vehicleRouteDataApi);
			}
		};
		String body=JSON.toJSONString(vehicleRouteRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//LED设备控屏
	public static String control(ControlRequest controlRequest ){
		String controlDataApi = ARTEMIS_PATH +"/api/pms/v1/device/led/control";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",controlDataApi);
			}
		};
		String body=JSON.toJSONString(controlRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//查询优惠规则列表
	public static String search(SearchRequest searchRequest ){
		String searchDataApi = ARTEMIS_PATH +"/api/pms/v1/reductRule/search";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",searchDataApi);
			}
		};
		String body=JSON.toJSONString(searchRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//查询停车库剩余诱导车位数
	public static String remainSpaceNum(RemainSpaceNumRequest remainSpaceNumRequest ){
		String remainSpaceNumDataApi = ARTEMIS_PATH +"/api/pms/v1/park/induce/remainSpaceNum";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",remainSpaceNumDataApi);
			}
		};
		String body=JSON.toJSONString(remainSpaceNumRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//查询出入口设备关联关系
	public static String search(SearchRequest searchRequest ){
		String searchDataApi = ARTEMIS_PATH +"/api/pms/v1/park/deviceRelation/search";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",searchDataApi);
			}
		};
		String body=JSON.toJSONString(searchRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//查询商户列表
	public static String search(SearchRequest searchRequest ){
		String searchDataApi = ARTEMIS_PATH +"/api/pms/v1/merchant/search";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",searchDataApi);
			}
		};
		String body=JSON.toJSONString(searchRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//查询车辆分类
	public static String category(CategoryRequest categoryRequest ){
		String categoryDataApi = ARTEMIS_PATH +"/api/pms/v1/car/category";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",categoryDataApi);
			}
		};
		String body=JSON.toJSONString(categoryRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//生成优惠券V2
	public static String addition(AdditionRequest additionRequest ){
		String additionDataApi = ARTEMIS_PATH +"/api/pms/v2/coupon/addition";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",additionDataApi);
			}
		};
		String body=JSON.toJSONString(additionRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//设备播报控制
	public static String control(ControlRequest controlRequest ){
		String controlDataApi = ARTEMIS_PATH +"/api/pms/v1/device/voice/control";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",controlDataApi);
			}
		};
		String body=JSON.toJSONString(controlRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//车位增量绑定车辆
	public static String batch(BatchRequest batchRequest ){
		String batchDataApi = ARTEMIS_PATH +"/api/pms/v1/parkingSpace/carBind/batch";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",batchDataApi);
			}
		};
		String body=JSON.toJSONString(batchRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//车辆群组查询接口
	public static String search(SearchRequest searchRequest ){
		String searchDataApi = ARTEMIS_PATH +"/api/pms/v1/car/category/search";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",searchDataApi);
			}
		};
		String body=JSON.toJSONString(searchRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//车辆群组管理
	public static String categoryBind(CategoryBindRequest categoryBindRequest ){
		String categoryBindDataApi = ARTEMIS_PATH +"/api/pms/v1/car/categoryBind";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",categoryBindDataApi);
			}
		};
		String body=JSON.toJSONString(categoryBindRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//车辆群组管理接口V2
	public static String categoryBind(CategoryBindRequest categoryBindRequest ){
		String categoryBindDataApi = ARTEMIS_PATH +"/api/pms/v2/car/categoryBind";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",categoryBindDataApi);
			}
		};
		String body=JSON.toJSONString(categoryBindRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}


}
