
import java.util.HashMap;
import java.util.Map;

import com.alibaba.fastjson.JSONObject;
import com.hikvision.artemis.sdk.ArtemisHttpUtil;
import com.hikvision.artemis.sdk.config.ArtemisConfig;


/**
 * Auto Create on 2021-09-09 12:09:36
 */
public class ArtemisPostTest_车辆及车库信息接口 {
	/**
	 * STEP1：设置平台参数，根据实际情况,设置host appkey appsecret 三个参数.
	 */
	static {
		ArtemisConfig.host = "ip:port";// 平台门户/nginx的IP和端口（必须使用https协议，https端口默认为443）
		ArtemisConfig.appKey = "请填入appKey"; // 秘钥appkey
		ArtemisConfig.appSecret = "请填入appSecret";// 秘钥appSecret
	}
	/**
	 * STEP2：设置OpenAPI接口的上下文
	 */
	private static final String ARTEMIS_PATH = "/artemis";

	//获取停车库列表
	public static String parkList(ParkListRequest parkListRequest ){
		String parkListDataApi = ARTEMIS_PATH +"/api/resource/v1/park/parkList";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",parkListDataApi);
			}
		};
		String body=JSON.toJSONString(parkListRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//获取停车库节点详细信息
	public static String get(GetRequest getRequest ){
		String getDataApi = ARTEMIS_PATH +"/api/resource/v1/park/detail/get";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",getDataApi);
			}
		};
		String body=JSON.toJSONString(getRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//查询停车库节点信息
	public static String search(SearchRequest searchRequest ){
		String searchDataApi = ARTEMIS_PATH +"/api/resource/v1/park/search";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",searchDataApi);
			}
		};
		String body=JSON.toJSONString(searchRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//获取出入口列表
	public static String entranceList(EntranceListRequest entranceListRequest ){
		String entranceListDataApi = ARTEMIS_PATH +"/api/resource/v1/entrance/entranceList";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",entranceListDataApi);
			}
		};
		String body=JSON.toJSONString(entranceListRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//获取车道列表
	public static String roadwayList(RoadwayListRequest roadwayListRequest ){
		String roadwayListDataApi = ARTEMIS_PATH +"/api/resource/v1/roadway/roadwayList";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",roadwayListDataApi);
			}
		};
		String body=JSON.toJSONString(roadwayListRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//批量添加车辆
	public static String add(AddRequest addRequest ){
		String addDataApi = ARTEMIS_PATH +"/api/resource/v1/vehicle/batch/add";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",addDataApi);
			}
		};
		String body=JSON.toJSONString(addRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//修改车辆
	public static String update(UpdateRequest updateRequest ){
		String updateDataApi = ARTEMIS_PATH +"/api/resource/v1/vehicle/single/update";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",updateDataApi);
			}
		};
		String body=JSON.toJSONString(updateRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//批量删除车辆
	public static String delete(DeleteRequest deleteRequest ){
		String deleteDataApi = ARTEMIS_PATH +"/api/resource/v1/vehicle/batch/delete";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",deleteDataApi);
			}
		};
		String body=JSON.toJSONString(deleteRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//查询车辆列表v2
	public static String vehicleList(VehicleListRequest vehicleListRequest ){
		String vehicleListDataApi = ARTEMIS_PATH +"/api/resource/v2/vehicle/advance/vehicleList";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",vehicleListDataApi);
			}
		};
		String body=JSON.toJSONString(vehicleListRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//增量获取停车库数据
	public static String timeRange(TimeRangeRequest timeRangeRequest ){
		String timeRangeDataApi = ARTEMIS_PATH +"/api/resource/v1/park/timeRange";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",timeRangeDataApi);
			}
		};
		String body=JSON.toJSONString(timeRangeRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//增量获取车辆数据
	public static String timeRange(TimeRangeRequest timeRangeRequest ){
		String timeRangeDataApi = ARTEMIS_PATH +"/api/resource/v1/vehicle/timeRange";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",timeRangeDataApi);
			}
		};
		String body=JSON.toJSONString(timeRangeRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}


}
