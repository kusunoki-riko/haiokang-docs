public class SearchRequest {
	private Integer pageNo;
	private Integer pageSize;
	private String startTime;
	private String endTime;
	private ArrayList<String> deviceIndexCodes;

	public Integer getPageNo() {
		return pageNo;
	}

	public void setPageNo(Integer pageNo) {
		this.pageNo = pageNo;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public ArrayList<String> getDeviceIndexCodes() {
		return deviceIndexCodes;
	}

	public void setDeviceIndexCodes(ArrayList<String> deviceIndexCodes) {
		this.deviceIndexCodes = deviceIndexCodes;
	}
}
