public class DeleteRequest {
	private String indexCodes;

	public String getIndexCodes() {
		return indexCodes;
	}

	public void setIndexCodes(String indexCodes) {
		this.indexCodes = indexCodes;
	}
}
