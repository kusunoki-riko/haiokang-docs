public class DeleteRequest {
	private ArrayList<String> vehicleIds;

	public ArrayList<String> getVehicleIds() {
		return vehicleIds;
	}

	public void setVehicleIds(ArrayList<String> vehicleIds) {
		this.vehicleIds = vehicleIds;
	}
}
