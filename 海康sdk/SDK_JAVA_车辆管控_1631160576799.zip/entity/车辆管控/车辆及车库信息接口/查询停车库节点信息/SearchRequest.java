public class SearchRequest {
	private String parentIndexCode;
	private String parentResourceType;
	private ArrayList<String> resourceTypes;
	private String name;
	private String orderBy;
	private String orderType;
	private Integer pageSize;
	private Integer pageNo;

	public String getParentIndexCode() {
		return parentIndexCode;
	}

	public void setParentIndexCode(String parentIndexCode) {
		this.parentIndexCode = parentIndexCode;
	}

	public String getParentResourceType() {
		return parentResourceType;
	}

	public void setParentResourceType(String parentResourceType) {
		this.parentResourceType = parentResourceType;
	}

	public ArrayList<String> getResourceTypes() {
		return resourceTypes;
	}

	public void setResourceTypes(ArrayList<String> resourceTypes) {
		this.resourceTypes = resourceTypes;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getOrderBy() {
		return orderBy;
	}

	public void setOrderBy(String orderBy) {
		this.orderBy = orderBy;
	}

	public String getOrderType() {
		return orderType;
	}

	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}

	public Integer getPageNo() {
		return pageNo;
	}

	public void setPageNo(Integer pageNo) {
		this.pageNo = pageNo;
	}
}
