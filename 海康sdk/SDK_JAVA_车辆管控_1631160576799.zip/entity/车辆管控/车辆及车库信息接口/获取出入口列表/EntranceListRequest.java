public class EntranceListRequest {
	private String parkIndexCodes;

	public String getParkIndexCodes() {
		return parkIndexCodes;
	}

	public void setParkIndexCodes(String parkIndexCodes) {
		this.parkIndexCodes = parkIndexCodes;
	}
}
