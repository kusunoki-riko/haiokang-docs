public class RoadwayListRequest {
	private String entranceIndexCodes;

	public String getEntranceIndexCodes() {
		return entranceIndexCodes;
	}

	public void setEntranceIndexCodes(String entranceIndexCodes) {
		this.entranceIndexCodes = entranceIndexCodes;
	}
}
