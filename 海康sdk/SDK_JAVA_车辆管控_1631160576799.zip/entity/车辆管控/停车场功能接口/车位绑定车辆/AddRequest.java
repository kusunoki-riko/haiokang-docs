public class AddRequest {
	private String spaceNos;
	private String floorSyscode;
	private String plateNos;
	private Integer bindType;

	public String getSpaceNos() {
		return spaceNos;
	}

	public void setSpaceNos(String spaceNos) {
		this.spaceNos = spaceNos;
	}

	public String getFloorSyscode() {
		return floorSyscode;
	}

	public void setFloorSyscode(String floorSyscode) {
		this.floorSyscode = floorSyscode;
	}

	public String getPlateNos() {
		return plateNos;
	}

	public void setPlateNos(String plateNos) {
		this.plateNos = plateNos;
	}

	public Integer getBindType() {
		return bindType;
	}

	public void setBindType(Integer bindType) {
		this.bindType = bindType;
	}
}
