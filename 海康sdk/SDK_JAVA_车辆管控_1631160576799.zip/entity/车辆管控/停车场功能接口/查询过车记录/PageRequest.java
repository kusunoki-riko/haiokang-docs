public class PageRequest {
	private String parkSyscode;
	private String entranceSyscode;
	private String plateNo;
	private String cardNo;
	private String startTime;
	private String endTime;
	private Integer vehicleOut;
	private Integer vehicleType;
	private Integer releaseResult;
	private Integer releaseWay;
	private Integer releaseReason;
	private String carCategory;
	private Integer pageNo;
	private Integer pageSize;

	public String getParkSyscode() {
		return parkSyscode;
	}

	public void setParkSyscode(String parkSyscode) {
		this.parkSyscode = parkSyscode;
	}

	public String getEntranceSyscode() {
		return entranceSyscode;
	}

	public void setEntranceSyscode(String entranceSyscode) {
		this.entranceSyscode = entranceSyscode;
	}

	public String getPlateNo() {
		return plateNo;
	}

	public void setPlateNo(String plateNo) {
		this.plateNo = plateNo;
	}

	public String getCardNo() {
		return cardNo;
	}

	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public Integer getVehicleOut() {
		return vehicleOut;
	}

	public void setVehicleOut(Integer vehicleOut) {
		this.vehicleOut = vehicleOut;
	}

	public Integer getVehicleType() {
		return vehicleType;
	}

	public void setVehicleType(Integer vehicleType) {
		this.vehicleType = vehicleType;
	}

	public Integer getReleaseResult() {
		return releaseResult;
	}

	public void setReleaseResult(Integer releaseResult) {
		this.releaseResult = releaseResult;
	}

	public Integer getReleaseWay() {
		return releaseWay;
	}

	public void setReleaseWay(Integer releaseWay) {
		this.releaseWay = releaseWay;
	}

	public Integer getReleaseReason() {
		return releaseReason;
	}

	public void setReleaseReason(Integer releaseReason) {
		this.releaseReason = releaseReason;
	}

	public String getCarCategory() {
		return carCategory;
	}

	public void setCarCategory(String carCategory) {
		this.carCategory = carCategory;
	}

	public Integer getPageNo() {
		return pageNo;
	}

	public void setPageNo(Integer pageNo) {
		this.pageNo = pageNo;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}
}
