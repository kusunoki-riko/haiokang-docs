public class RemainSpaceNumRequest {
	private String parkSyscode;
	private String floorSyscode;

	public String getParkSyscode() {
		return parkSyscode;
	}

	public void setParkSyscode(String parkSyscode) {
		this.parkSyscode = parkSyscode;
	}

	public String getFloorSyscode() {
		return floorSyscode;
	}

	public void setFloorSyscode(String floorSyscode) {
		this.floorSyscode = floorSyscode;
	}
}
