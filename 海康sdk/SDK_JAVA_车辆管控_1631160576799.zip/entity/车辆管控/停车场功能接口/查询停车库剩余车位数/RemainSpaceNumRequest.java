public class RemainSpaceNumRequest {
	private String parkSyscode;

	public String getParkSyscode() {
		return parkSyscode;
	}

	public void setParkSyscode(String parkSyscode) {
		this.parkSyscode = parkSyscode;
	}
}
