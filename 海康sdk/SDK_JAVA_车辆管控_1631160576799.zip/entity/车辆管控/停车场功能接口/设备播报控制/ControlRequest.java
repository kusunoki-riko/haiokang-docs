public class ControlRequest {
	private String deviceSyscode;
	private String roadwaySyscode;
	private String voiceContent;

	public String getDeviceSyscode() {
		return deviceSyscode;
	}

	public void setDeviceSyscode(String deviceSyscode) {
		this.deviceSyscode = deviceSyscode;
	}

	public String getRoadwaySyscode() {
		return roadwaySyscode;
	}

	public void setRoadwaySyscode(String roadwaySyscode) {
		this.roadwaySyscode = roadwaySyscode;
	}

	public String getVoiceContent() {
		return voiceContent;
	}

	public void setVoiceContent(String voiceContent) {
		this.voiceContent = voiceContent;
	}
}
