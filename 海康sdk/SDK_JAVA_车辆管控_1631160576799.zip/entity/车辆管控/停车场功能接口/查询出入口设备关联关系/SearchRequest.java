public class SearchRequest {
	private String syscode;
	private Integer nodeType;
	private Boolean subNode;
	private String deviceType;

	public String getSyscode() {
		return syscode;
	}

	public void setSyscode(String syscode) {
		this.syscode = syscode;
	}

	public Integer getNodeType() {
		return nodeType;
	}

	public void setNodeType(Integer nodeType) {
		this.nodeType = nodeType;
	}

	public Boolean getSubNode() {
		return subNode;
	}

	public void setSubNode(Boolean subNode) {
		this.subNode = subNode;
	}

	public String getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}
}
