public class PreBillRequest {
	private String inRecordSyscode;
	private String roadwaySyscode;
	private String plateNo;
	private String parkSyscode;
	private String couponCode;
	private Integer deductRuleType;
	private String deductContent;

	public String getInRecordSyscode() {
		return inRecordSyscode;
	}

	public void setInRecordSyscode(String inRecordSyscode) {
		this.inRecordSyscode = inRecordSyscode;
	}

	public String getRoadwaySyscode() {
		return roadwaySyscode;
	}

	public void setRoadwaySyscode(String roadwaySyscode) {
		this.roadwaySyscode = roadwaySyscode;
	}

	public String getPlateNo() {
		return plateNo;
	}

	public void setPlateNo(String plateNo) {
		this.plateNo = plateNo;
	}

	public String getParkSyscode() {
		return parkSyscode;
	}

	public void setParkSyscode(String parkSyscode) {
		this.parkSyscode = parkSyscode;
	}

	public String getCouponCode() {
		return couponCode;
	}

	public void setCouponCode(String couponCode) {
		this.couponCode = couponCode;
	}

	public Integer getDeductRuleType() {
		return deductRuleType;
	}

	public void setDeductRuleType(Integer deductRuleType) {
		this.deductRuleType = deductRuleType;
	}

	public String getDeductContent() {
		return deductContent;
	}

	public void setDeductContent(String deductContent) {
		this.deductContent = deductContent;
	}
}
