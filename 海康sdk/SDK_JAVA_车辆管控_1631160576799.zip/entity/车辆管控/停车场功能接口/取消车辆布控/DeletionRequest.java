public class DeletionRequest {
	private String alarmSyscodes;

	public String getAlarmSyscodes() {
		return alarmSyscodes;
	}

	public void setAlarmSyscodes(String alarmSyscodes) {
		this.alarmSyscodes = alarmSyscodes;
	}
}
