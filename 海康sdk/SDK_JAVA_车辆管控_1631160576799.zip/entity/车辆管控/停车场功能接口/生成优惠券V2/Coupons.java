public class Coupons {
	private String ruleSyscode;
	private String merchantSyscode;
	private String couponCode;
	private String plateNo;
	private Integer deductRuleType;
	private Integer deductContent;
	private String parkSyscode;
	private String startTime;
	private String endTime;

	public String getRuleSyscode() {
		return ruleSyscode;
	}

	public void setRuleSyscode(String ruleSyscode) {
		this.ruleSyscode = ruleSyscode;
	}

	public String getMerchantSyscode() {
		return merchantSyscode;
	}

	public void setMerchantSyscode(String merchantSyscode) {
		this.merchantSyscode = merchantSyscode;
	}

	public String getCouponCode() {
		return couponCode;
	}

	public void setCouponCode(String couponCode) {
		this.couponCode = couponCode;
	}

	public String getPlateNo() {
		return plateNo;
	}

	public void setPlateNo(String plateNo) {
		this.plateNo = plateNo;
	}

	public Integer getDeductRuleType() {
		return deductRuleType;
	}

	public void setDeductRuleType(Integer deductRuleType) {
		this.deductRuleType = deductRuleType;
	}

	public Integer getDeductContent() {
		return deductContent;
	}

	public void setDeductContent(Integer deductContent) {
		this.deductContent = deductContent;
	}

	public String getParkSyscode() {
		return parkSyscode;
	}

	public void setParkSyscode(String parkSyscode) {
		this.parkSyscode = parkSyscode;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
}
