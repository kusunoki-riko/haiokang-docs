public class AdditionRequest {
	private ArrayList<Coupons> coupons;

	public ArrayList<Coupons> getCoupons() {
		return coupons;
	}

	public void setCoupons(ArrayList<Coupons> coupons) {
		this.coupons = coupons;
	}
}
