public class VehicleRouteRequest {
	private String originFloorSyscode;
	private String originLong;
	private String originLat;
	private String endSpaceSyscode;

	public String getOriginFloorSyscode() {
		return originFloorSyscode;
	}

	public void setOriginFloorSyscode(String originFloorSyscode) {
		this.originFloorSyscode = originFloorSyscode;
	}

	public String getOriginLong() {
		return originLong;
	}

	public void setOriginLong(String originLong) {
		this.originLong = originLong;
	}

	public String getOriginLat() {
		return originLat;
	}

	public void setOriginLat(String originLat) {
		this.originLat = originLat;
	}

	public String getEndSpaceSyscode() {
		return endSpaceSyscode;
	}

	public void setEndSpaceSyscode(String endSpaceSyscode) {
		this.endSpaceSyscode = endSpaceSyscode;
	}
}
