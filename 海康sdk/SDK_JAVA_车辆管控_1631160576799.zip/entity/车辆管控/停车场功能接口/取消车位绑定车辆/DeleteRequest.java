public class DeleteRequest {
	private String spaceNos;
	private String floorSyscode;
	private String plateNos;

	public String getSpaceNos() {
		return spaceNos;
	}

	public void setSpaceNos(String spaceNos) {
		this.spaceNos = spaceNos;
	}

	public String getFloorSyscode() {
		return floorSyscode;
	}

	public void setFloorSyscode(String floorSyscode) {
		this.floorSyscode = floorSyscode;
	}

	public String getPlateNos() {
		return plateNos;
	}

	public void setPlateNos(String plateNos) {
		this.plateNos = plateNos;
	}
}
