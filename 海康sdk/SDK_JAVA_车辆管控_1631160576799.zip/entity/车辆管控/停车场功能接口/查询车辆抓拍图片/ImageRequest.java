public class ImageRequest {
	private String aswSyscode;
	private String picUri;

	public String getAswSyscode() {
		return aswSyscode;
	}

	public void setAswSyscode(String aswSyscode) {
		this.aswSyscode = aswSyscode;
	}

	public String getPicUri() {
		return picUri;
	}

	public void setPicUri(String picUri) {
		this.picUri = picUri;
	}
}
