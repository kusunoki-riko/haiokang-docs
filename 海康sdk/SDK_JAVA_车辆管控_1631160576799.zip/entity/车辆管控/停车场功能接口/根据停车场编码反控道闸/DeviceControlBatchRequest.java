public class DeviceControlBatchRequest {
	private String parkSyscode;
	private Integer command;

	public String getParkSyscode() {
		return parkSyscode;
	}

	public void setParkSyscode(String parkSyscode) {
		this.parkSyscode = parkSyscode;
	}

	public Integer getCommand() {
		return command;
	}

	public void setCommand(Integer command) {
		this.command = command;
	}
}
