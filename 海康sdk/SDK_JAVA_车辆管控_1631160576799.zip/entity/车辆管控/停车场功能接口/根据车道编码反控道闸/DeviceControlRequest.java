public class DeviceControlRequest {
	private String roadwaySyscode;
	private Integer command;

	public String getRoadwaySyscode() {
		return roadwaySyscode;
	}

	public void setRoadwaySyscode(String roadwaySyscode) {
		this.roadwaySyscode = roadwaySyscode;
	}

	public Integer getCommand() {
		return command;
	}

	public void setCommand(Integer command) {
		this.command = command;
	}
}
