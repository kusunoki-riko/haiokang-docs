public class ReceiptRequest {
	private String billSyscode;

	public String getBillSyscode() {
		return billSyscode;
	}

	public void setBillSyscode(String billSyscode) {
		this.billSyscode = billSyscode;
	}
}
