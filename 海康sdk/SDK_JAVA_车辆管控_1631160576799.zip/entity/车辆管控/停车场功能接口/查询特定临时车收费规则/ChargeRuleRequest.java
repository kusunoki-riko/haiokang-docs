public class ChargeRuleRequest {
	private String chargeRuleSyscode;

	public String getChargeRuleSyscode() {
		return chargeRuleSyscode;
	}

	public void setChargeRuleSyscode(String chargeRuleSyscode) {
		this.chargeRuleSyscode = chargeRuleSyscode;
	}
}
