public class LedContent {
	private Integer line;
	private String fontConfig;
	private String showConfig;

	public Integer getLine() {
		return line;
	}

	public void setLine(Integer line) {
		this.line = line;
	}

	public String getFontConfig() {
		return fontConfig;
	}

	public void setFontConfig(String fontConfig) {
		this.fontConfig = fontConfig;
	}

	public String getShowConfig() {
		return showConfig;
	}

	public void setShowConfig(String showConfig) {
		this.showConfig = showConfig;
	}
}
