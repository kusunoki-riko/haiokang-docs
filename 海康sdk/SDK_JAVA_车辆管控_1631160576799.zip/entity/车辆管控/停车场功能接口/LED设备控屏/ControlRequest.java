public class ControlRequest {
	private String deviceSyscode;
	private String roadwaySyscode;
	private LedContent ledContent;

	public String getDeviceSyscode() {
		return deviceSyscode;
	}

	public void setDeviceSyscode(String deviceSyscode) {
		this.deviceSyscode = deviceSyscode;
	}

	public String getRoadwaySyscode() {
		return roadwaySyscode;
	}

	public void setRoadwaySyscode(String roadwaySyscode) {
		this.roadwaySyscode = roadwaySyscode;
	}

	public LedContent getLedContent() {
		return ledContent;
	}

	public void setLedContent(LedContent ledContent) {
		this.ledContent = ledContent;
	}
}
