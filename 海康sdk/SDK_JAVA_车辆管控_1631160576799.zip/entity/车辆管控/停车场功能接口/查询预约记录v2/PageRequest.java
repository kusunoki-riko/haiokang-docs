public class PageRequest {
	private String parkSyscode;
	private String plateNo;
	private Integer resvState;
	private Integer resvWay;
	private Integer allowTimes;
	private Integer isCharge;
	private String startTime;
	private String endTime;
	private Integer pageNo;
	private Integer pageSize;

	public String getParkSyscode() {
		return parkSyscode;
	}

	public void setParkSyscode(String parkSyscode) {
		this.parkSyscode = parkSyscode;
	}

	public String getPlateNo() {
		return plateNo;
	}

	public void setPlateNo(String plateNo) {
		this.plateNo = plateNo;
	}

	public Integer getResvState() {
		return resvState;
	}

	public void setResvState(Integer resvState) {
		this.resvState = resvState;
	}

	public Integer getResvWay() {
		return resvWay;
	}

	public void setResvWay(Integer resvWay) {
		this.resvWay = resvWay;
	}

	public Integer getAllowTimes() {
		return allowTimes;
	}

	public void setAllowTimes(Integer allowTimes) {
		this.allowTimes = allowTimes;
	}

	public Integer getIsCharge() {
		return isCharge;
	}

	public void setIsCharge(Integer isCharge) {
		this.isCharge = isCharge;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public Integer getPageNo() {
		return pageNo;
	}

	public void setPageNo(Integer pageNo) {
		this.pageNo = pageNo;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}
}
