public class DetailRequest {
	private ArrayList<String> personJobNos;

	public ArrayList<String> getPersonJobNos() {
		return personJobNos;
	}

	public void setPersonJobNos(ArrayList<String> personJobNos) {
		this.personJobNos = personJobNos;
	}
}
