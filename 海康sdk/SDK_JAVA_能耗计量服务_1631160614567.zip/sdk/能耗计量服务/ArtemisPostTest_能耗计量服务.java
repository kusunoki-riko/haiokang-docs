
import java.util.HashMap;
import java.util.Map;

import com.alibaba.fastjson.JSONObject;
import com.hikvision.artemis.sdk.ArtemisHttpUtil;
import com.hikvision.artemis.sdk.config.ArtemisConfig;


/**
 * Auto Create on 2021-09-09 12:10:14
 */
public class ArtemisPostTest_能耗计量服务 {
	/**
	 * STEP1：设置平台参数，根据实际情况,设置host appkey appsecret 三个参数.
	 */
	static {
		ArtemisConfig.host = "ip:port";// 平台门户/nginx的IP和端口（必须使用https协议，https端口默认为443）
		ArtemisConfig.appKey = "请填入appKey"; // 秘钥appkey
		ArtemisConfig.appSecret = "请填入appSecret";// 秘钥appSecret
	}
	/**
	 * STEP2：设置OpenAPI接口的上下文
	 */
	private static final String ARTEMIS_PATH = "/artemis";

	//分页获取用电结构树
	public static String tree(TreeRequest treeRequest ){
		String treeDataApi = ARTEMIS_PATH +"/api/third/v1/energy/node/tree";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",treeDataApi);
			}
		};
		String body=JSON.toJSONString(treeRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//根据时间维度获取区域用量排名
	public static String regionDataRanking(RegionDataRankingRequest regionDataRankingRequest ){
		String regionDataRankingDataApi = ARTEMIS_PATH +"/api/ecm/v1/energy/regionDataRanking";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",regionDataRankingDataApi);
			}
		};
		String body=JSON.toJSONString(regionDataRankingRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//根据时间维度获取能耗分布
	public static String energyDistribution(EnergyDistributionRequest energyDistributionRequest ){
		String energyDistributionDataApi = ARTEMIS_PATH +"/api/ecm/v1/energy/energyDistribution";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",energyDistributionDataApi);
			}
		};
		String body=JSON.toJSONString(energyDistributionRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//根据时间维度获取能耗总费用
	public static String totalCost(TotalCostRequest totalCostRequest ){
		String totalCostDataApi = ARTEMIS_PATH +"/api/ecm/v1/energy/totalCost";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",totalCostDataApi);
			}
		};
		String body=JSON.toJSONString(totalCostRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//根据时间获取园区内的各用能总量
	public static String energyTotal(EnergyTotalRequest energyTotalRequest ){
		String energyTotalDataApi = ARTEMIS_PATH +"/api/ecm/v1/energy/energyTotal";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",energyTotalDataApi);
			}
		};
		String body=JSON.toJSONString(energyTotalRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//根据时间获取能耗用量趋势
	public static String energyTrend(EnergyTrendRequest energyTrendRequest ){
		String energyTrendDataApi = ARTEMIS_PATH +"/api/ecm/v1/energy/energyTrend";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",energyTrendDataApi);
			}
		};
		String body=JSON.toJSONString(energyTrendRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//根据时间获取部门用量排名
	public static String orgDataRanking(OrgDataRankingRequest orgDataRankingRequest ){
		String orgDataRankingDataApi = ARTEMIS_PATH +"/api/ecm/v1/energy/orgDataRanking";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",orgDataRankingDataApi);
			}
		};
		String body=JSON.toJSONString(orgDataRankingRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}


}
