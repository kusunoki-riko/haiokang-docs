public class LossRequest {
	private ArrayList<CardList> cardList;

	public ArrayList<CardList> getCardList() {
		return cardList;
	}

	public void setCardList(ArrayList<CardList> cardList) {
		this.cardList = cardList;
	}
}
