public class OrgInfoRequest {
	private ArrayList<String> orgIndexCodes;

	public ArrayList<String> getOrgIndexCodes() {
		return orgIndexCodes;
	}

	public void setOrgIndexCodes(ArrayList<String> orgIndexCodes) {
		this.orgIndexCodes = orgIndexCodes;
	}
}
