public class DeleteRequest {
	private ArrayList<String> personIds;

	public ArrayList<String> getPersonIds() {
		return personIds;
	}

	public void setPersonIds(ArrayList<String> personIds) {
		this.personIds = personIds;
	}
}
