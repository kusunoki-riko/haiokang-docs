public class PictureRequest {
	private String picUri;
	private String serverIndexCode;

	public String getPicUri() {
		return picUri;
	}

	public void setPicUri(String picUri) {
		this.picUri = picUri;
	}

	public String getServerIndexCode() {
		return serverIndexCode;
	}

	public void setServerIndexCode(String serverIndexCode) {
		this.serverIndexCode = serverIndexCode;
	}
}
