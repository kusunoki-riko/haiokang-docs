public class PersonInfoRequest {
	private String paramName;
	private ArrayList<String> paramValue;

	public String getParamName() {
		return paramName;
	}

	public void setParamName(String paramName) {
		this.paramName = paramName;
	}

	public ArrayList<String> getParamValue() {
		return paramValue;
	}

	public void setParamValue(ArrayList<String> paramValue) {
		this.paramValue = paramValue;
	}
}
