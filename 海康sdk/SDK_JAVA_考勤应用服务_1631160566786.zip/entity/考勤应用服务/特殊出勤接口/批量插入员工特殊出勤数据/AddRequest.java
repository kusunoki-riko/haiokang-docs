public class AddRequest {
	private ArrayList<AddAttendanceList> addAttendanceList;

	public ArrayList<AddAttendanceList> getAddAttendanceList() {
		return addAttendanceList;
	}

	public void setAddAttendanceList(ArrayList<AddAttendanceList> addAttendanceList) {
		this.addAttendanceList = addAttendanceList;
	}
}
