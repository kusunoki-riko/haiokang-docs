public class UpdateRequest {
	private ArrayList<UpdateAttendanceList> updateAttendanceList;

	public ArrayList<UpdateAttendanceList> getUpdateAttendanceList() {
		return updateAttendanceList;
	}

	public void setUpdateAttendanceList(ArrayList<UpdateAttendanceList> updateAttendanceList) {
		this.updateAttendanceList = updateAttendanceList;
	}
}
