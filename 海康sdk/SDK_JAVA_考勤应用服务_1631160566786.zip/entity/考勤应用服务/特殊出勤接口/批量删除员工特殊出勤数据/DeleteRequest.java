public class DeleteRequest {
	private ArrayList<String> delAttendanceList;

	public ArrayList<String> getDelAttendanceList() {
		return delAttendanceList;
	}

	public void setDelAttendanceList(ArrayList<String> delAttendanceList) {
		this.delAttendanceList = delAttendanceList;
	}
}
