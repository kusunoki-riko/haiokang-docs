public class ClockList {
	private String clockId;
	private String personId;
	private String certNum;
	private String jobNo;
	private Integer clockType;
	private String clockTime;
	private String clockPlaceName;
	private Integer isValid;
	private Integer isInOut;

	public String getClockId() {
		return clockId;
	}

	public void setClockId(String clockId) {
		this.clockId = clockId;
	}

	public String getPersonId() {
		return personId;
	}

	public void setPersonId(String personId) {
		this.personId = personId;
	}

	public String getCertNum() {
		return certNum;
	}

	public void setCertNum(String certNum) {
		this.certNum = certNum;
	}

	public String getJobNo() {
		return jobNo;
	}

	public void setJobNo(String jobNo) {
		this.jobNo = jobNo;
	}

	public Integer getClockType() {
		return clockType;
	}

	public void setClockType(Integer clockType) {
		this.clockType = clockType;
	}

	public String getClockTime() {
		return clockTime;
	}

	public void setClockTime(String clockTime) {
		this.clockTime = clockTime;
	}

	public String getClockPlaceName() {
		return clockPlaceName;
	}

	public void setClockPlaceName(String clockPlaceName) {
		this.clockPlaceName = clockPlaceName;
	}

	public Integer getIsValid() {
		return isValid;
	}

	public void setIsValid(Integer isValid) {
		this.isValid = isValid;
	}

	public Integer getIsInOut() {
		return isInOut;
	}

	public void setIsInOut(Integer isInOut) {
		this.isInOut = isInOut;
	}
}
