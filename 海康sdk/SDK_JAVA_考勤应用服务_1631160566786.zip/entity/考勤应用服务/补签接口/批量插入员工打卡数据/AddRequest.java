public class AddRequest {
	private ArrayList<ClockList> clockList;

	public ArrayList<ClockList> getClockList() {
		return clockList;
	}

	public void setClockList(ArrayList<ClockList> clockList) {
		this.clockList = clockList;
	}
}
