public class UpdateRequest {
	private ArrayList<UpdateClockList> updateClockList;

	public ArrayList<UpdateClockList> getUpdateClockList() {
		return updateClockList;
	}

	public void setUpdateClockList(ArrayList<UpdateClockList> updateClockList) {
		this.updateClockList = updateClockList;
	}
}
