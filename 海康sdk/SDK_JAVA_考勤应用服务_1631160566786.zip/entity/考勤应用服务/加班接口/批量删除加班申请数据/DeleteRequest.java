public class DeleteRequest {
	private ArrayList<String> delOvertimeIds;

	public ArrayList<String> getDelOvertimeIds() {
		return delOvertimeIds;
	}

	public void setDelOvertimeIds(ArrayList<String> delOvertimeIds) {
		this.delOvertimeIds = delOvertimeIds;
	}
}
