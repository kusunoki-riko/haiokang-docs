public class OvertimeList {
	private String overtimeId;
	private String personId;
	private String certNum;
	private String jobNo;
	private Integer isButch;
	private String startDate;
	private String endDate;
	private String startTime;
	private String endTime;
	private String byRestOrMoney;

	public String getOvertimeId() {
		return overtimeId;
	}

	public void setOvertimeId(String overtimeId) {
		this.overtimeId = overtimeId;
	}

	public String getPersonId() {
		return personId;
	}

	public void setPersonId(String personId) {
		this.personId = personId;
	}

	public String getCertNum() {
		return certNum;
	}

	public void setCertNum(String certNum) {
		this.certNum = certNum;
	}

	public String getJobNo() {
		return jobNo;
	}

	public void setJobNo(String jobNo) {
		this.jobNo = jobNo;
	}

	public Integer getIsButch() {
		return isButch;
	}

	public void setIsButch(Integer isButch) {
		this.isButch = isButch;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public String getByRestOrMoney() {
		return byRestOrMoney;
	}

	public void setByRestOrMoney(String byRestOrMoney) {
		this.byRestOrMoney = byRestOrMoney;
	}
}
