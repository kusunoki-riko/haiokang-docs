public class AddRequest {
	private ArrayList<OvertimeList> overtimeList;

	public ArrayList<OvertimeList> getOvertimeList() {
		return overtimeList;
	}

	public void setOvertimeList(ArrayList<OvertimeList> overtimeList) {
		this.overtimeList = overtimeList;
	}
}
