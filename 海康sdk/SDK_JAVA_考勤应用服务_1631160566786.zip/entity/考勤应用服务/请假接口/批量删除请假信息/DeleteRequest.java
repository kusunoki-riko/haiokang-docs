public class DeleteRequest {
	private ArrayList<String> delLeaveIdList;

	public ArrayList<String> getDelLeaveIdList() {
		return delLeaveIdList;
	}

	public void setDelLeaveIdList(ArrayList<String> delLeaveIdList) {
		this.delLeaveIdList = delLeaveIdList;
	}
}
