public class AddRequest {
	private ArrayList<LeaveList> leaveList;

	public ArrayList<LeaveList> getLeaveList() {
		return leaveList;
	}

	public void setLeaveList(ArrayList<LeaveList> leaveList) {
		this.leaveList = leaveList;
	}
}
