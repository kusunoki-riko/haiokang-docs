public class ListRequest {
	private Integer pageNo;
	private Integer pageSize;
	private String fields;
	private ArrayList<FieldOptions> fieldOptions;
	private ArrayList<Sorts> sorts;

	public Integer getPageNo() {
		return pageNo;
	}

	public void setPageNo(Integer pageNo) {
		this.pageNo = pageNo;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}

	public String getFields() {
		return fields;
	}

	public void setFields(String fields) {
		this.fields = fields;
	}

	public ArrayList<FieldOptions> getFieldOptions() {
		return fieldOptions;
	}

	public void setFieldOptions(ArrayList<FieldOptions> fieldOptions) {
		this.fieldOptions = fieldOptions;
	}

	public ArrayList<Sorts> getSorts() {
		return sorts;
	}

	public void setSorts(ArrayList<Sorts> sorts) {
		this.sorts = sorts;
	}
}
