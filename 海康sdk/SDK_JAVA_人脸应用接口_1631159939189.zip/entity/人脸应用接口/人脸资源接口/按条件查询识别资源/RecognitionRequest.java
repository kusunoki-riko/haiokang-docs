public class RecognitionRequest {
	private ArrayList<String> indexCodes;
	private String name;
	private String recognitionResourceType;

	public ArrayList<String> getIndexCodes() {
		return indexCodes;
	}

	public void setIndexCodes(ArrayList<String> indexCodes) {
		this.indexCodes = indexCodes;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRecognitionResourceType() {
		return recognitionResourceType;
	}

	public void setRecognitionResourceType(String recognitionResourceType) {
		this.recognitionResourceType = recognitionResourceType;
	}
}
