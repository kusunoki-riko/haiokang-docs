public class SearchRequest {
	private Integer pageNo;
	private Integer pageSize;
	private String startTime;
	private String endTime;
	private ArrayList<String> cameraIndexCodes;
	private ArrayList<String> age;
	private String gender;
	private String glass;

	public Integer getPageNo() {
		return pageNo;
	}

	public void setPageNo(Integer pageNo) {
		this.pageNo = pageNo;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public ArrayList<String> getCameraIndexCodes() {
		return cameraIndexCodes;
	}

	public void setCameraIndexCodes(ArrayList<String> cameraIndexCodes) {
		this.cameraIndexCodes = cameraIndexCodes;
	}

	public ArrayList<String> getAge() {
		return age;
	}

	public void setAge(ArrayList<String> age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getGlass() {
		return glass;
	}

	public void setGlass(String glass) {
		this.glass = glass;
	}
}
