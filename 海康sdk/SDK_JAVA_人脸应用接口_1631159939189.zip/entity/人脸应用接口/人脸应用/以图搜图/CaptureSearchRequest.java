public class CaptureSearchRequest {
	private Integer pageNo;
	private Integer pageSize;
	private String facePicBinaryData;
	private String facePicUrl;
	private ArrayList<String> cameraIndexCodes;
	private Integer searchNum;
	private String startTime;
	private String endTime;
	private Integer minSimilarity;
	private Integer maxSimilarity;
	private Integer age;
	private String ageGroup;
	private String sex;
	private String withGlass;
	private String smile;
	private String isEthnic;

	public Integer getPageNo() {
		return pageNo;
	}

	public void setPageNo(Integer pageNo) {
		this.pageNo = pageNo;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}

	public String getFacePicBinaryData() {
		return facePicBinaryData;
	}

	public void setFacePicBinaryData(String facePicBinaryData) {
		this.facePicBinaryData = facePicBinaryData;
	}

	public String getFacePicUrl() {
		return facePicUrl;
	}

	public void setFacePicUrl(String facePicUrl) {
		this.facePicUrl = facePicUrl;
	}

	public ArrayList<String> getCameraIndexCodes() {
		return cameraIndexCodes;
	}

	public void setCameraIndexCodes(ArrayList<String> cameraIndexCodes) {
		this.cameraIndexCodes = cameraIndexCodes;
	}

	public Integer getSearchNum() {
		return searchNum;
	}

	public void setSearchNum(Integer searchNum) {
		this.searchNum = searchNum;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public Integer getMinSimilarity() {
		return minSimilarity;
	}

	public void setMinSimilarity(Integer minSimilarity) {
		this.minSimilarity = minSimilarity;
	}

	public Integer getMaxSimilarity() {
		return maxSimilarity;
	}

	public void setMaxSimilarity(Integer maxSimilarity) {
		this.maxSimilarity = maxSimilarity;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public String getAgeGroup() {
		return ageGroup;
	}

	public void setAgeGroup(String ageGroup) {
		this.ageGroup = ageGroup;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getWithGlass() {
		return withGlass;
	}

	public void setWithGlass(String withGlass) {
		this.withGlass = withGlass;
	}

	public String getSmile() {
		return smile;
	}

	public void setSmile(String smile) {
		this.smile = smile;
	}

	public String getIsEthnic() {
		return isEthnic;
	}

	public void setIsEthnic(String isEthnic) {
		this.isEthnic = isEthnic;
	}
}
