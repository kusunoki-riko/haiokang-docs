public class OneToManyRequest {
	private Integer pageNo;
	private Integer pageSize;
	private Integer searchNum;
	private Integer minSimilarity;
	private String facePicUrl;
	private String facePicBinaryData;
	private ArrayList<String> faceGroupIndexCodes;
	private String name;
	private String sex;
	private String certificateType;
	private String certificateNum;

	public Integer getPageNo() {
		return pageNo;
	}

	public void setPageNo(Integer pageNo) {
		this.pageNo = pageNo;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}

	public Integer getSearchNum() {
		return searchNum;
	}

	public void setSearchNum(Integer searchNum) {
		this.searchNum = searchNum;
	}

	public Integer getMinSimilarity() {
		return minSimilarity;
	}

	public void setMinSimilarity(Integer minSimilarity) {
		this.minSimilarity = minSimilarity;
	}

	public String getFacePicUrl() {
		return facePicUrl;
	}

	public void setFacePicUrl(String facePicUrl) {
		this.facePicUrl = facePicUrl;
	}

	public String getFacePicBinaryData() {
		return facePicBinaryData;
	}

	public void setFacePicBinaryData(String facePicBinaryData) {
		this.facePicBinaryData = facePicBinaryData;
	}

	public ArrayList<String> getFaceGroupIndexCodes() {
		return faceGroupIndexCodes;
	}

	public void setFaceGroupIndexCodes(ArrayList<String> faceGroupIndexCodes) {
		this.faceGroupIndexCodes = faceGroupIndexCodes;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getCertificateType() {
		return certificateType;
	}

	public void setCertificateType(String certificateType) {
		this.certificateType = certificateType;
	}

	public String getCertificateNum() {
		return certificateNum;
	}

	public void setCertificateNum(String certificateNum) {
		this.certificateNum = certificateNum;
	}
}
