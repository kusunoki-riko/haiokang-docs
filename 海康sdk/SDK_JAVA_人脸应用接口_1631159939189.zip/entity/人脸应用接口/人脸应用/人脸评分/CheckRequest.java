public class CheckRequest {
	private String facePicUrl;

	public String getFacePicUrl() {
		return facePicUrl;
	}

	public void setFacePicUrl(String facePicUrl) {
		this.facePicUrl = facePicUrl;
	}
}
