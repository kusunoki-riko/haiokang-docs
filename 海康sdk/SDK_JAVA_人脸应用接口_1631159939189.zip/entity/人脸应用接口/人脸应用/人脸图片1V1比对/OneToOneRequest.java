public class OneToOneRequest {
	private String srcFacePicBinaryData;
	private String srcFacePicUrl;
	private String distFacePicBinaryData;
	private String distFacePicUrl;

	public String getSrcFacePicBinaryData() {
		return srcFacePicBinaryData;
	}

	public void setSrcFacePicBinaryData(String srcFacePicBinaryData) {
		this.srcFacePicBinaryData = srcFacePicBinaryData;
	}

	public String getSrcFacePicUrl() {
		return srcFacePicUrl;
	}

	public void setSrcFacePicUrl(String srcFacePicUrl) {
		this.srcFacePicUrl = srcFacePicUrl;
	}

	public String getDistFacePicBinaryData() {
		return distFacePicBinaryData;
	}

	public void setDistFacePicBinaryData(String distFacePicBinaryData) {
		this.distFacePicBinaryData = distFacePicBinaryData;
	}

	public String getDistFacePicUrl() {
		return distFacePicUrl;
	}

	public void setDistFacePicUrl(String distFacePicUrl) {
		this.distFacePicUrl = distFacePicUrl;
	}
}
