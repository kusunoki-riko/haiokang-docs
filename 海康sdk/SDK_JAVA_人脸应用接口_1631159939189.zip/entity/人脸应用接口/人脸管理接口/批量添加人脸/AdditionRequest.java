public class AdditionRequest {
	private String indexCode;
	private String faceGroupIndexCode;

	public String getIndexCode() {
		return indexCode;
	}

	public void setIndexCode(String indexCode) {
		this.indexCode = indexCode;
	}

	public String getFaceGroupIndexCode() {
		return faceGroupIndexCode;
	}

	public void setFaceGroupIndexCode(String faceGroupIndexCode) {
		this.faceGroupIndexCode = faceGroupIndexCode;
	}
}
