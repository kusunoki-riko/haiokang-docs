public class FaceRequest {
	private String certificateNum;
	private String certificateType;
	private String faceGroupIndexCode;
	private ArrayList<String> indexCodes;
	private String name;
	private Integer pageNo;
	private Integer pageSize;
	private String sex;

	public String getCertificateNum() {
		return certificateNum;
	}

	public void setCertificateNum(String certificateNum) {
		this.certificateNum = certificateNum;
	}

	public String getCertificateType() {
		return certificateType;
	}

	public void setCertificateType(String certificateType) {
		this.certificateType = certificateType;
	}

	public String getFaceGroupIndexCode() {
		return faceGroupIndexCode;
	}

	public void setFaceGroupIndexCode(String faceGroupIndexCode) {
		this.faceGroupIndexCode = faceGroupIndexCode;
	}

	public ArrayList<String> getIndexCodes() {
		return indexCodes;
	}

	public void setIndexCodes(ArrayList<String> indexCodes) {
		this.indexCodes = indexCodes;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getPageNo() {
		return pageNo;
	}

	public void setPageNo(Integer pageNo) {
		this.pageNo = pageNo;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}
}
