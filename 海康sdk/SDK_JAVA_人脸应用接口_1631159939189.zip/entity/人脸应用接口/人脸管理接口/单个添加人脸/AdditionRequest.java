public class AdditionRequest {
	private String faceGroupIndexCode;
	private FaceInfo faceInfo;
	private FacePic facePic;

	public String getFaceGroupIndexCode() {
		return faceGroupIndexCode;
	}

	public void setFaceGroupIndexCode(String faceGroupIndexCode) {
		this.faceGroupIndexCode = faceGroupIndexCode;
	}

	public FaceInfo getFaceInfo() {
		return faceInfo;
	}

	public void setFaceInfo(FaceInfo faceInfo) {
		this.faceInfo = faceInfo;
	}

	public FacePic getFacePic() {
		return facePic;
	}

	public void setFacePic(FacePic facePic) {
		this.facePic = facePic;
	}
}
