public class AdditionRequest {
	private String name;
	private ArrayList<String> faceGroupIndexCodes;
	private ArrayList<String> cameraIndexCodes;
	private ArrayList<String> recognitionResourceIndexCodes;
	private String recognitionResourceType;
	private String description;
	private Integer threshold;
	private ArrayList<TimeBlockList> timeBlockList;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public ArrayList<String> getFaceGroupIndexCodes() {
		return faceGroupIndexCodes;
	}

	public void setFaceGroupIndexCodes(ArrayList<String> faceGroupIndexCodes) {
		this.faceGroupIndexCodes = faceGroupIndexCodes;
	}

	public ArrayList<String> getCameraIndexCodes() {
		return cameraIndexCodes;
	}

	public void setCameraIndexCodes(ArrayList<String> cameraIndexCodes) {
		this.cameraIndexCodes = cameraIndexCodes;
	}

	public ArrayList<String> getRecognitionResourceIndexCodes() {
		return recognitionResourceIndexCodes;
	}

	public void setRecognitionResourceIndexCodes(ArrayList<String> recognitionResourceIndexCodes) {
		this.recognitionResourceIndexCodes = recognitionResourceIndexCodes;
	}

	public String getRecognitionResourceType() {
		return recognitionResourceType;
	}

	public void setRecognitionResourceType(String recognitionResourceType) {
		this.recognitionResourceType = recognitionResourceType;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getThreshold() {
		return threshold;
	}

	public void setThreshold(Integer threshold) {
		this.threshold = threshold;
	}

	public ArrayList<TimeBlockList> getTimeBlockList() {
		return timeBlockList;
	}

	public void setTimeBlockList(ArrayList<TimeBlockList> timeBlockList) {
		this.timeBlockList = timeBlockList;
	}
}
