public class CopyRequest {
	private ArrayList<String> indexCodes;
	private ArrayList<String> faceGroupIndexCodes;

	public ArrayList<String> getIndexCodes() {
		return indexCodes;
	}

	public void setIndexCodes(ArrayList<String> indexCodes) {
		this.indexCodes = indexCodes;
	}

	public ArrayList<String> getFaceGroupIndexCodes() {
		return faceGroupIndexCodes;
	}

	public void setFaceGroupIndexCodes(ArrayList<String> faceGroupIndexCodes) {
		this.faceGroupIndexCodes = faceGroupIndexCodes;
	}
}
