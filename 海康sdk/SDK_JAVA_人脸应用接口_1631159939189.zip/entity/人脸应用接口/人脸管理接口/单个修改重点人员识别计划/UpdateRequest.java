public class UpdateRequest {
	private String indexCode;
	private String name;
	private ArrayList<String> faceGroupIndexCodes;
	private ArrayList<String> recognitionResourceIndexCodes;
	private ArrayList<String> cameraIndexCodes;
	private String description;
	private Integer threshold;
	private ArrayList<TimeBlockList> timeBlockList;

	public String getIndexCode() {
		return indexCode;
	}

	public void setIndexCode(String indexCode) {
		this.indexCode = indexCode;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public ArrayList<String> getFaceGroupIndexCodes() {
		return faceGroupIndexCodes;
	}

	public void setFaceGroupIndexCodes(ArrayList<String> faceGroupIndexCodes) {
		this.faceGroupIndexCodes = faceGroupIndexCodes;
	}

	public ArrayList<String> getRecognitionResourceIndexCodes() {
		return recognitionResourceIndexCodes;
	}

	public void setRecognitionResourceIndexCodes(ArrayList<String> recognitionResourceIndexCodes) {
		this.recognitionResourceIndexCodes = recognitionResourceIndexCodes;
	}

	public ArrayList<String> getCameraIndexCodes() {
		return cameraIndexCodes;
	}

	public void setCameraIndexCodes(ArrayList<String> cameraIndexCodes) {
		this.cameraIndexCodes = cameraIndexCodes;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getThreshold() {
		return threshold;
	}

	public void setThreshold(Integer threshold) {
		this.threshold = threshold;
	}

	public ArrayList<TimeBlockList> getTimeBlockList() {
		return timeBlockList;
	}

	public void setTimeBlockList(ArrayList<TimeBlockList> timeBlockList) {
		this.timeBlockList = timeBlockList;
	}
}
