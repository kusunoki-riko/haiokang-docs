public class TimeBlockList {
	private String dayOfWeek;
	private ArrayList<TimeRange> timeRange;

	public String getDayOfWeek() {
		return dayOfWeek;
	}

	public void setDayOfWeek(String dayOfWeek) {
		this.dayOfWeek = dayOfWeek;
	}

	public ArrayList<TimeRange> getTimeRange() {
		return timeRange;
	}

	public void setTimeRange(ArrayList<TimeRange> timeRange) {
		this.timeRange = timeRange;
	}
}
