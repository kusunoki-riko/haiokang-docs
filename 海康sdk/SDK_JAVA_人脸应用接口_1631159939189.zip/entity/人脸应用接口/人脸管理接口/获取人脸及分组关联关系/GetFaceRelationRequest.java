public class GetFaceRelationRequest {
	private ArrayList<String> indexCodes;

	public ArrayList<String> getIndexCodes() {
		return indexCodes;
	}

	public void setIndexCodes(ArrayList<String> indexCodes) {
		this.indexCodes = indexCodes;
	}
}
