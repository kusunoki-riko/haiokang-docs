public class DeletionRequest {
	private ArrayList<String> indexCodes;
	private String faceGroupIndexCode;

	public ArrayList<String> getIndexCodes() {
		return indexCodes;
	}

	public void setIndexCodes(ArrayList<String> indexCodes) {
		this.indexCodes = indexCodes;
	}

	public String getFaceGroupIndexCode() {
		return faceGroupIndexCode;
	}

	public void setFaceGroupIndexCode(String faceGroupIndexCode) {
		this.faceGroupIndexCode = faceGroupIndexCode;
	}
}
