public class ConfigurationRequest {
	private Boolean eventSwitch;

	public Boolean getEventSwitch() {
		return eventSwitch;
	}

	public void setEventSwitch(Boolean eventSwitch) {
		this.eventSwitch = eventSwitch;
	}
}
