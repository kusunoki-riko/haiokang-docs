public class WhiteRequest {
	private String description;
	private ArrayList<String> faceGroupIndexCodes;
	private String name;
	private String status;

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public ArrayList<String> getFaceGroupIndexCodes() {
		return faceGroupIndexCodes;
	}

	public void setFaceGroupIndexCodes(ArrayList<String> faceGroupIndexCodes) {
		this.faceGroupIndexCodes = faceGroupIndexCodes;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
}
