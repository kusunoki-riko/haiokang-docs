public class UpdateRequest {
	private String indexCode;
	private FaceInfo faceInfo;
	private FacePic facePic;

	public String getIndexCode() {
		return indexCode;
	}

	public void setIndexCode(String indexCode) {
		this.indexCode = indexCode;
	}

	public FaceInfo getFaceInfo() {
		return faceInfo;
	}

	public void setFaceInfo(FaceInfo faceInfo) {
		this.faceInfo = faceInfo;
	}

	public FacePic getFacePic() {
		return facePic;
	}

	public void setFacePic(FacePic facePic) {
		this.facePic = facePic;
	}
}
