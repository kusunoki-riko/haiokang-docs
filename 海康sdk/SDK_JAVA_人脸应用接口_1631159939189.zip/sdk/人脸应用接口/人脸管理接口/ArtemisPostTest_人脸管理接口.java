
import java.util.HashMap;
import java.util.Map;

import com.alibaba.fastjson.JSONObject;
import com.hikvision.artemis.sdk.ArtemisHttpUtil;
import com.hikvision.artemis.sdk.config.ArtemisConfig;


/**
 * Auto Create on 2021-09-09 11:58:59
 */
public class ArtemisPostTest_人脸管理接口 {
	/**
	 * STEP1：设置平台参数，根据实际情况,设置host appkey appsecret 三个参数.
	 */
	static {
		ArtemisConfig.host = "ip:port";// 平台门户/nginx的IP和端口（必须使用https协议，https端口默认为443）
		ArtemisConfig.appKey = "请填入appKey"; // 秘钥appkey
		ArtemisConfig.appSecret = "请填入appSecret";// 秘钥appSecret
	}
	/**
	 * STEP2：设置OpenAPI接口的上下文
	 */
	private static final String ARTEMIS_PATH = "/artemis";

	//删除人脸分组
	public static String deletion(DeletionRequest deletionRequest ){
		String deletionDataApi = ARTEMIS_PATH +"/api/frs/v1/face/group/batch/deletion";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",deletionDataApi);
			}
		};
		String body=JSON.toJSONString(deletionRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//删除重点人员识别计划
	public static String deletion(DeletionRequest deletionRequest ){
		String deletionDataApi = ARTEMIS_PATH +"/api/frs/v1/plan/recognition/black/deletion";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",deletionDataApi);
			}
		};
		String body=JSON.toJSONString(deletionRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//删除陌生人识别计划
	public static String deletion(DeletionRequest deletionRequest ){
		String deletionDataApi = ARTEMIS_PATH +"/api/frs/v1/plan/recognition/white/deletion";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",deletionDataApi);
			}
		};
		String body=JSON.toJSONString(deletionRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//单个修改人脸
	public static String update(UpdateRequest updateRequest ){
		String updateDataApi = ARTEMIS_PATH +"/api/frs/v1/face/single/update";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",updateDataApi);
			}
		};
		String body=JSON.toJSONString(updateRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//单个修改人脸分组
	public static String update(UpdateRequest updateRequest ){
		String updateDataApi = ARTEMIS_PATH +"/api/frs/v1/face/group/single/update";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",updateDataApi);
			}
		};
		String body=JSON.toJSONString(updateRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//单个修改重点人员识别计划
	public static String update(UpdateRequest updateRequest ){
		String updateDataApi = ARTEMIS_PATH +"/api/frs/v1/plan/recognition/black/update";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",updateDataApi);
			}
		};
		String body=JSON.toJSONString(updateRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//单个修改陌生人识别计划
	public static String update(UpdateRequest updateRequest ){
		String updateDataApi = ARTEMIS_PATH +"/api/frs/v1/plan/recognition/white/update";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",updateDataApi);
			}
		};
		String body=JSON.toJSONString(updateRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//单个查询重点人员识别计划详情
	public static String detail(DetailRequest detailRequest ){
		String detailDataApi = ARTEMIS_PATH +"/api/frs/v1/plan/recognition/black/detail";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",detailDataApi);
			}
		};
		String body=JSON.toJSONString(detailRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//单个查询陌生人识别计划详情
	public static String detail(DetailRequest detailRequest ){
		String detailDataApi = ARTEMIS_PATH +"/api/frs/v1/plan/recognition/white/detail";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",detailDataApi);
			}
		};
		String body=JSON.toJSONString(detailRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//单个添加人脸
	public static String addition(AdditionRequest additionRequest ){
		String additionDataApi = ARTEMIS_PATH +"/api/frs/v1/face/single/addition";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",additionDataApi);
			}
		};
		String body=JSON.toJSONString(additionRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//单个添加人脸分组
	public static String addition(AdditionRequest additionRequest ){
		String additionDataApi = ARTEMIS_PATH +"/api/frs/v1/face/group/single/addition";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",additionDataApi);
			}
		};
		String body=JSON.toJSONString(additionRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//单个添加重点人员识别计划
	public static String addition(AdditionRequest additionRequest ){
		String additionDataApi = ARTEMIS_PATH +"/api/frs/v1/plan/recognition/black/addition";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",additionDataApi);
			}
		};
		String body=JSON.toJSONString(additionRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//单个添加陌生人识别计划
	public static String addition(AdditionRequest additionRequest ){
		String additionDataApi = ARTEMIS_PATH +"/api/frs/v1/plan/recognition/white/addition";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",additionDataApi);
			}
		};
		String body=JSON.toJSONString(additionRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//批量删除人脸
	public static String deletion(DeletionRequest deletionRequest ){
		String deletionDataApi = ARTEMIS_PATH +"/api/frs/v1/face/deletion";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",deletionDataApi);
			}
		};
		String body=JSON.toJSONString(deletionRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//批量拷贝人脸到人脸分组
	public static String copy(CopyRequest copyRequest ){
		String copyDataApi = ARTEMIS_PATH +"/api/frs/v1/face/batch/copy";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",copyDataApi);
			}
		};
		String body=JSON.toJSONString(copyRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//批量添加人脸
	public static String addition(AdditionRequest additionRequest ){
		String additionDataApi = ARTEMIS_PATH +"/api/frs/v1/face/batch/addition";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",additionDataApi);
			}
		};
		String body=JSON.toJSONString(additionRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//抓拍计划配置
	public static String configuration(ConfigurationRequest configurationRequest ){
		String configurationDataApi = ARTEMIS_PATH +"/api/frs/v1/plan/capture/configuration";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",configurationDataApi);
			}
		};
		String body=JSON.toJSONString(configurationRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//按条件批量查询人脸
	public static String face(FaceRequest faceRequest ){
		String faceDataApi = ARTEMIS_PATH +"/api/frs/v1/face";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",faceDataApi);
			}
		};
		String body=JSON.toJSONString(faceRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//按条件查询人脸分组
	public static String group(GroupRequest groupRequest ){
		String groupDataApi = ARTEMIS_PATH +"/api/frs/v1/face/group";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",groupDataApi);
			}
		};
		String body=JSON.toJSONString(groupRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//查询重点人员识别计划
	public static String black(BlackRequest blackRequest ){
		String blackDataApi = ARTEMIS_PATH +"/api/frs/v1/plan/recognition/black";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",blackDataApi);
			}
		};
		String body=JSON.toJSONString(blackRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//查询陌生人识别计划
	public static String white(WhiteRequest whiteRequest ){
		String whiteDataApi = ARTEMIS_PATH +"/api/frs/v1/plan/recognition/white";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",whiteDataApi);
			}
		};
		String body=JSON.toJSONString(whiteRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//获取人脸及分组关联关系
	public static String getFaceRelation(GetFaceRelationRequest getFaceRelationRequest ){
		String getFaceRelationDataApi = ARTEMIS_PATH +"/api/frs/v1/plan/getFaceRelation";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",getFaceRelationDataApi);
			}
		};
		String body=JSON.toJSONString(getFaceRelationRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//重新下发重点人员识别计划
	public static String restart(RestartRequest restartRequest ){
		String restartDataApi = ARTEMIS_PATH +"/api/frs/v1/plan/recognition/black/restart";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",restartDataApi);
			}
		};
		String body=JSON.toJSONString(restartRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//重新下发陌生人识别计划
	public static String restart(RestartRequest restartRequest ){
		String restartDataApi = ARTEMIS_PATH +"/api/frs/v1/plan/recognition/white/restart";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",restartDataApi);
			}
		};
		String body=JSON.toJSONString(restartRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}


}
