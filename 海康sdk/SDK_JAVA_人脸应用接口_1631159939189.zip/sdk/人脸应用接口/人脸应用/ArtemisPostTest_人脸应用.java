
import java.util.HashMap;
import java.util.Map;

import com.alibaba.fastjson.JSONObject;
import com.hikvision.artemis.sdk.ArtemisHttpUtil;
import com.hikvision.artemis.sdk.config.ArtemisConfig;


/**
 * Auto Create on 2021-09-09 11:58:59
 */
public class ArtemisPostTest_人脸应用 {
	/**
	 * STEP1：设置平台参数，根据实际情况,设置host appkey appsecret 三个参数.
	 */
	static {
		ArtemisConfig.host = "ip:port";// 平台门户/nginx的IP和端口（必须使用https协议，https端口默认为443）
		ArtemisConfig.appKey = "请填入appKey"; // 秘钥appkey
		ArtemisConfig.appSecret = "请填入appSecret";// 秘钥appSecret
	}
	/**
	 * STEP2：设置OpenAPI接口的上下文
	 */
	private static final String ARTEMIS_PATH = "/artemis";

	//人脸分组1VN检索
	public static String oneToMany(OneToManyRequest oneToManyRequest ){
		String oneToManyDataApi = ARTEMIS_PATH +"/api/frs/v1/application/oneToMany";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",oneToManyDataApi);
			}
		};
		String body=JSON.toJSONString(oneToManyRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//人脸图片1V1比对
	public static String oneToOne(OneToOneRequest oneToOneRequest ){
		String oneToOneDataApi = ARTEMIS_PATH +"/api/frs/v1/application/oneToOne";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",oneToOneDataApi);
			}
		};
		String body=JSON.toJSONString(oneToOneRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//人脸服务图片下载
	public static String picture(PictureRequest pictureRequest ){
		String pictureDataApi = ARTEMIS_PATH +"/api/frs/v1/application/picture";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",pictureDataApi);
			}
		};
		String body=JSON.toJSONString(pictureRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//人脸评分
	public static String check(CheckRequest checkRequest ){
		String checkDataApi = ARTEMIS_PATH +"/api/frs/v1/face/picture/check";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",checkDataApi);
			}
		};
		String body=JSON.toJSONString(checkRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//以图搜图
	public static String captureSearch(CaptureSearchRequest captureSearchRequest ){
		String captureSearchDataApi = ARTEMIS_PATH +"/api/frs/v1/application/captureSearch";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",captureSearchDataApi);
			}
		};
		String body=JSON.toJSONString(captureSearchRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//按条件查询人脸抓拍事件
	public static String search(SearchRequest searchRequest ){
		String searchDataApi = ARTEMIS_PATH +"/api/frs/v1/event/face_capture/search";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",searchDataApi);
			}
		};
		String body=JSON.toJSONString(searchRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//按条件查询重点人员事件
	public static String search(SearchRequest searchRequest ){
		String searchDataApi = ARTEMIS_PATH +"/api/frs/v1/event/black/search";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",searchDataApi);
			}
		};
		String body=JSON.toJSONString(searchRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//按条件查询陌生人事件
	public static String search(SearchRequest searchRequest ){
		String searchDataApi = ARTEMIS_PATH +"/api/frs/v1/event/stranger/search";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",searchDataApi);
			}
		};
		String body=JSON.toJSONString(searchRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//按条件查询高频人员识别事件
	public static String search(SearchRequest searchRequest ){
		String searchDataApi = ARTEMIS_PATH +"/api/frs/v1/event/high_frequency/search";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",searchDataApi);
			}
		};
		String body=JSON.toJSONString(searchRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}


}
