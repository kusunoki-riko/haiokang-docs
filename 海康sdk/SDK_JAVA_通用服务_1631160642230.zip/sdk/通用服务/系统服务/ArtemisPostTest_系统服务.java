
import java.util.HashMap;
import java.util.Map;

import com.alibaba.fastjson.JSONObject;
import com.hikvision.artemis.sdk.ArtemisHttpUtil;
import com.hikvision.artemis.sdk.config.ArtemisConfig;


/**
 * Auto Create on 2021-09-09 12:10:42
 */
public class ArtemisPostTest_系统服务 {
	/**
	 * STEP1：设置平台参数，根据实际情况,设置host appkey appsecret 三个参数.
	 */
	static {
		ArtemisConfig.host = "ip:port";// 平台门户/nginx的IP和端口（必须使用https协议，https端口默认为443）
		ArtemisConfig.appKey = "请填入appKey"; // 秘钥appkey
		ArtemisConfig.appSecret = "请填入appSecret";// 秘钥appSecret
	}
	/**
	 * STEP2：设置OpenAPI接口的上下文
	 */
	private static final String ARTEMIS_PATH = "/artemis";

	//分页获取用户信息
	public static String users(UsersRequest usersRequest ){
		String usersDataApi = ARTEMIS_PATH +"/api/userService/v1/users";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",usersDataApi);
			}
		};
		String body=JSON.toJSONString(usersRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//客户端登出接口
	public static String logoutByCTGT(LogoutByCTGTRequest logoutByCTGTRequest ){
		String logoutByCTGTDataApi = ARTEMIS_PATH +"/api/bic/ssoService/v1/logoutByCTGT";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",logoutByCTGTDataApi);
			}
		};
		String body=JSON.toJSONString(logoutByCTGTRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//核心服务寻址
	public static String service(ServiceRequest serviceRequest ){
		String serviceDataApi = ARTEMIS_PATH +"/api/bic/v1/svrService/service";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",serviceDataApi);
			}
		};
		String body=JSON.toJSONString(serviceRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//获取API网关接口调用token
	public static String token(TokenRequest tokenRequest ){
		String tokenDataApi = ARTEMIS_PATH +"/api/v1/oauth/token";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",tokenDataApi);
			}
		};
		String body=JSON.toJSONString(tokenRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}


}
