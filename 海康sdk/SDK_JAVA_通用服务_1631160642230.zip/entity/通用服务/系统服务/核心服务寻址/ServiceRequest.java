public class ServiceRequest {
	private String ctgt;

	public String getCtgt() {
		return ctgt;
	}

	public void setCtgt(String ctgt) {
		this.ctgt = ctgt;
	}
}
