
import java.util.HashMap;
import java.util.Map;

import com.alibaba.fastjson.JSONObject;
import com.hikvision.artemis.sdk.ArtemisHttpUtil;
import com.hikvision.artemis.sdk.config.ArtemisConfig;


/**
 * Auto Create on 2021-09-09 12:10:23
 */
public class ArtemisPostTest_视频标签管理应用服务 {
	/**
	 * STEP1：设置平台参数，根据实际情况,设置host appkey appsecret 三个参数.
	 */
	static {
		ArtemisConfig.host = "ip:port";// 平台门户/nginx的IP和端口（必须使用https协议，https端口默认为443）
		ArtemisConfig.appKey = "请填入appKey"; // 秘钥appkey
		ArtemisConfig.appSecret = "请填入appSecret";// 秘钥appSecret
	}
	/**
	 * STEP2：设置OpenAPI接口的上下文
	 */
	private static final String ARTEMIS_PATH = "/artemis";

	//产线实时数据上报
	public static String line(LineRequest lineRequest ){
		String lineDataApi = ARTEMIS_PATH +"/api/thirdApiService/v1/reatimeDatas/line";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",lineDataApi);
			}
		};
		String body=JSON.toJSONString(lineRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//点位实时数据上报接口
	public static String point(PointRequest pointRequest ){
		String pointDataApi = ARTEMIS_PATH +"/api/thirdApiService/v1/reatimeDatas/point";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",pointDataApi);
			}
		};
		String body=JSON.toJSONString(pointRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//告警上报接口
	public static String alarms(AlarmsRequest alarmsRequest ){
		String alarmsDataApi = ARTEMIS_PATH +"/api/thirdApiService/v1/alarms";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",alarmsDataApi);
			}
		};
		String body=JSON.toJSONString(alarmsRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}


}
