public class Data {
	private String id;
	private String name;
	private String status;
	private String opTotalQty;
	private String currentMo;
	private String currentItem;
	private String planQty;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getOpTotalQty() {
		return opTotalQty;
	}

	public void setOpTotalQty(String opTotalQty) {
		this.opTotalQty = opTotalQty;
	}

	public String getCurrentMo() {
		return currentMo;
	}

	public void setCurrentMo(String currentMo) {
		this.currentMo = currentMo;
	}

	public String getCurrentItem() {
		return currentItem;
	}

	public void setCurrentItem(String currentItem) {
		this.currentItem = currentItem;
	}

	public String getPlanQty() {
		return planQty;
	}

	public void setPlanQty(String planQty) {
		this.planQty = planQty;
	}
}
