public class ImportBillsRequest {
	private String billName;
	private String startTime;
	private String endTime;
	private Integer feeType;
	private ArrayList<BillList> billList;

	public String getBillName() {
		return billName;
	}

	public void setBillName(String billName) {
		this.billName = billName;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public Integer getFeeType() {
		return feeType;
	}

	public void setFeeType(Integer feeType) {
		this.feeType = feeType;
	}

	public ArrayList<BillList> getBillList() {
		return billList;
	}

	public void setBillList(ArrayList<BillList> billList) {
		this.billList = billList;
	}
}
