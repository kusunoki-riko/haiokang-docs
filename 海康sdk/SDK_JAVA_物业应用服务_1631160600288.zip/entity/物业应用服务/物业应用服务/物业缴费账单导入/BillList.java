public class BillList {
	private String tempBillUUId;
	private String roomFullPathCode;
	private String amount;
	private String beforeUsageNum;
	private String currentUsageNum;
	private String realityUsageNum;
	private String usageType;

	public String getTempBillUUId() {
		return tempBillUUId;
	}

	public void setTempBillUUId(String tempBillUUId) {
		this.tempBillUUId = tempBillUUId;
	}

	public String getRoomFullPathCode() {
		return roomFullPathCode;
	}

	public void setRoomFullPathCode(String roomFullPathCode) {
		this.roomFullPathCode = roomFullPathCode;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getBeforeUsageNum() {
		return beforeUsageNum;
	}

	public void setBeforeUsageNum(String beforeUsageNum) {
		this.beforeUsageNum = beforeUsageNum;
	}

	public String getCurrentUsageNum() {
		return currentUsageNum;
	}

	public void setCurrentUsageNum(String currentUsageNum) {
		this.currentUsageNum = currentUsageNum;
	}

	public String getRealityUsageNum() {
		return realityUsageNum;
	}

	public void setRealityUsageNum(String realityUsageNum) {
		this.realityUsageNum = realityUsageNum;
	}

	public String getUsageType() {
		return usageType;
	}

	public void setUsageType(String usageType) {
		this.usageType = usageType;
	}
}
