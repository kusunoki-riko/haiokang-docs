public class DeleteBillsRequest {
	private ArrayList<String> uuidList;

	public ArrayList<String> getUuidList() {
		return uuidList;
	}

	public void setUuidList(ArrayList<String> uuidList) {
		this.uuidList = uuidList;
	}
}
