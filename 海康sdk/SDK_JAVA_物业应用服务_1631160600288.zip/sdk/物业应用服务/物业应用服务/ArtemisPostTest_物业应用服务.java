
import java.util.HashMap;
import java.util.Map;

import com.alibaba.fastjson.JSONObject;
import com.hikvision.artemis.sdk.ArtemisHttpUtil;
import com.hikvision.artemis.sdk.config.ArtemisConfig;


/**
 * Auto Create on 2021-09-09 12:10:00
 */
public class ArtemisPostTest_物业应用服务 {
	/**
	 * STEP1：设置平台参数，根据实际情况,设置host appkey appsecret 三个参数.
	 */
	static {
		ArtemisConfig.host = "ip:port";// 平台门户/nginx的IP和端口（必须使用https协议，https端口默认为443）
		ArtemisConfig.appKey = "请填入appKey"; // 秘钥appkey
		ArtemisConfig.appSecret = "请填入appSecret";// 秘钥appSecret
	}
	/**
	 * STEP2：设置OpenAPI接口的上下文
	 */
	private static final String ARTEMIS_PATH = "/artemis";

	//物业缴费账单删除
	public static String deleteBills(DeleteBillsRequest deleteBillsRequest ){
		String deleteBillsDataApi = ARTEMIS_PATH +"/api/cpms/v1/billForeign/deleteBills";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",deleteBillsDataApi);
			}
		};
		String body=JSON.toJSONString(deleteBillsRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}

	//物业缴费账单导入
	public static String importBills(ImportBillsRequest importBillsRequest ){
		String importBillsDataApi = ARTEMIS_PATH +"/api/cpms/v1/billForeign/importBills";
		Map<String,String> path = new HashMap<String,String>(2){
			{
				put("https://",importBillsDataApi);
			}
		};
		String body=JSON.toJSONString(importBillsRequest);
		String result =ArtemisHttpUtil.doPostStringArtemis(path,body,null,null,"application/json");
		return result;
	}


}
